const cloud = require('wx-server-sdk');
cloud.init({ env: process.env.TCB_ENV || process.env.TCB_ENV_ID || undefined });
const db = cloud.database();

function makePost(schoolId, board) {
  const now = new Date();
  return {
    school_id: schoolId,
    board: board || 'gossip',
    title: '自动生成的帖子',
    content: '系统自动生成内容',
    created_at: now,
    updated_at: now
  };
}

async function processOneTask(task) {
  const results = [];
  const count = Math.max(1, Math.min(20, Number(task.count) || 1));
  const board = task.board || 'gossip';
  let sid = task.school_id;

  // 如果 sid 是字符串且非数字，则当成名称查 schools 集合
  if (typeof sid === 'string' && isNaN(Number(sid))) {
    console.log('Lookup school by name:', sid);
    try {
      const r = await db.collection('schools').where({ name: sid }).limit(1).get();
      if (r.data && r.data.length) {
        const doc = r.data[0];
        sid = (typeof doc.id === 'number') ? doc.id : (doc.school_id !== undefined ? doc.school_id : doc._id);
        console.log('Resolved school doc:', JSON.stringify(doc));
      } else {
        console.log('School not found for name:', sid);
        return { task, ok: false, err: 'school not found' };
      }
    } catch (e) {
      console.error('Query schools failed:', e);
      return { task, ok: false, err: e.message || e };
    }
  }

  for (let i = 0; i < count; i++) {
    const post = makePost(sid, board);
    try {
      const addRes = await db.collection('posts').add({ data: post });
      console.log('Inserted post for school', sid, '->', JSON.stringify(addRes));
      results.push({ ok: true, id: addRes._id });
    } catch (err) {
      console.error('Insert failed for school', sid, err);
      results.push({ ok: false, err: err.message || err });
    }
  }

  return { task, ok: results.some(r => r.ok), results };
}

exports.main = async (event, context) => {
  try {
    // 如果触发器把实际参数放在 event.Message（字符串）里，先解析它
    if (event && event.Message && typeof event.Message === 'string' && event.Message.trim() !== '') {
      try {
        const parsed = JSON.parse(event.Message);
        event = Object.assign({}, parsed, event);
        console.log('Parsed event from Message:', JSON.stringify(parsed));
      } catch (e) {
        console.log('event.Message is not valid JSON:', event.Message);
      }
    }

    console.log('Event payload:', JSON.stringify(event));

    // 优先处理直接传入的 event（用于立即触发/测试）
    if (event && (event.school_id || event.school_ids || event.school)) {
      const task = {
        school_id: event.school_id || (event.school && (event.school.id || event.school._id || event.school.name)),
        count: event.count || 1,
        board: event.board || 'gossip'
      };
      const res = await processOneTask(task);
      return { ok: !!res.ok, results: [res] };
    }

    // 没有传入 event 参数：读取 post_scheduler 集合的 enabled 任务
    console.log('No event params; loading scheduled tasks from post_scheduler collection...');
    const tasksRes = await db.collection('post_scheduler').where({ enabled: true }).get();
    const tasks = (tasksRes && tasksRes.data) || [];
    if (tasks.length === 0) {
      console.log('No enabled tasks found in post_scheduler.');
      return { ok: false, message: 'no scheduled tasks' };
    }

    const allResults = [];
    for (const t of tasks) {
      const taskObj = {
        school_id: t.school_id,
        count: t.count || 1,
        board: t.board || 'gossip'
      };
      const r = await processOneTask(taskObj);
      allResults.push(r);
      // 可选：执行成功后可更新任务 last_run 或禁用，示例（注释掉，按需启用）：
      // await db.collection('post_scheduler').doc(t._id).update({ data: { last_run: new Date(), attempts: (t.attempts||0)+1 } });
    }

    return { ok: true, results: allResults };
  } catch (ex) {
    console.error('Unhandled error:', ex);
    return { ok: false, error: ex.message || ex };
  }
};