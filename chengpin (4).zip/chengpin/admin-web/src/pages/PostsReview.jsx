import React, { useEffect, useState } from 'react';
import { Table, Button, message } from 'antd';
import axios from '../utils/api';

export default function PostsReview() {
  const [data, setData] = useState([]);
  useEffect(() => {
    axios.get('/admin/posts').then(res => {
      if (res.ok) setData(res.data);
      else message.error(res.msg || '加载失败');
    });
  }, []);

  const approve = id => {
    axios.patch(`/admin/reviews/${id}`, { status: 'approved' }).then(res => {
      if (res.ok) message.success('已通过');
      else message.error(res.msg || '失败');
    });
  };

  const reject = id => {
    axios.patch(`/admin/reviews/${id}`, { status: 'rejected' }).then(res => {
      if (res.ok) message.success('已驳回');
      else message.error(res.msg || '失败');
    });
  };

  return (
    <Table
      dataSource={data}
      rowKey="_id"
      columns={[
        { title: '标题', dataIndex: 'title' },
        { title: '内容', dataIndex: 'content' },
        { title: '状态', dataIndex: 'status' },
        { title: '操作', render: (_, row) => (
          <>
            <Button onClick={() => approve(row._id)}>通过</Button>
            <Button danger onClick={() => reject(row._id)}>驳回</Button>
          </>
        )}
      ]}
    />
  );
}