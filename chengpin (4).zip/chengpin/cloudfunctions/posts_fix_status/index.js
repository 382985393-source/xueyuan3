'use strict'
// posts_fix_status：修正 posts 集合里 status 字段（单条或批量）
// 用法（在云函数测试面板填 event）：
// 单条： { "mode":"single", "id":"DOC_ID", "toStatus":"normal" }
// 批量： { "mode":"batch", "fromStatus":"done", "toStatus":"normal", "batchSize":100 }
// 建议先用 single 验证，再用 batch。

const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const posts = db.collection('posts')

exports.main = async (event, context) => {
  const mode = (event && event.mode) || 'batch'
  const now = new Date()
  try {
    if (mode === 'single') {
      const id = event.id
      const toStatus = event.toStatus || 'normal'
      if (!id) return { code: -1, msg: 'single mode requires id' }
      await posts.doc(id).update({
        data: {
          status: toStatus,
          published_at: toStatus === 'normal' ? now : null,
          published_by: toStatus === 'normal' ? 'fix-script' : null,
          auto_reason: (event.note || 'status fixed by script')
        }
      })
      return { code: 0, msg: 'updated single', id, toStatus }
    }

    // batch mode
    const fromStatus = event.fromStatus || 'done'
    const toStatus = event.toStatus || 'normal'
    const batchSize = Math.min(100, Math.max(10, parseInt(event.batchSize || 100, 10)))
    const limit = batchSize
    let totalProcessed = 0
    const processedIds = []

    while (true) {
      const q = await posts.where({
        status: fromStatus
      }).limit(limit).get()
      const list = q.data || []
      if (!list.length) break

      for (const doc of list) {
        try {
          await posts.doc(doc._id).update({
            data: {
              status: toStatus,
              published_at: toStatus === 'normal' ? now : null,
              published_by: toStatus === 'normal' ? 'fix-script' : null,
              auto_reason: (event.note || `status changed from ${fromStatus} to ${toStatus} by fix-script`)
            }
          })
          processedIds.push(doc._id)
          totalProcessed++
        } catch (e) {
          console.warn('update fail', doc._id, e.message || e)
        }
      }

      if (list.length < limit) break
    }

    return { code: 0, msg: 'batch update done', totalProcessed, processedIds }
  } catch (err) {
    console.error('posts_fix_status error', err)
    return { code: -1, msg: String(err) }
  }
}