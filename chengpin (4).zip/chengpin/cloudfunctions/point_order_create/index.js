const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { good_id } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!good_id) return { ok: false, msg: '参数缺失' };
  try {
    const goodRes = await db.collection('point_goods').doc(good_id).get();
    const good = goodRes.data;
    if (!good || good.status !== 'on' || good.stock < 1) return { ok: false, msg: '商品不可兑换' };

    await db.collection('point_orders').add({
      data: {
        good_id,
        openid,
        need_points: good.need_points,
        status: 'pending',
        created_at: Date.now()
      }
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};