const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const posts = db.collection('posts')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20, orderBy='created_at' } = data || {}
    return await posts.where(filter).orderBy(orderBy, 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await posts.doc(data.id).get()
  }
  if (action === 'delete') {
    await posts.doc(data.id).update({ data: { status: 'deleted' } })
    return { code: 0 }
  }
  if (action === 'edit') {
    await posts.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'top') {
    await posts.doc(data.id).update({ data: { is_top: data.is_top } })
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}