const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  try {
    // 支持按 id 查询单个商品
    if (event && event.id) {
      const res = await db.collection('market_items').where({ _id: event.id }).limit(1).get();
      return { ok: true, data: res.data || [] };
    }

    const page = Math.max(1, Number(event.page || 1));
    const pageSize = Math.max(1, Number(event.pageSize || 12));
    const q = (event.q || '').trim();

    let query = db.collection('market_items');
    if (q) {
      query = query.where({ title: db.RegExp({ regexp: q, options: 'i' }) });
    }

    const skip = (page - 1) * pageSize;
    const listRes = await query.skip(skip).limit(pageSize).get();
    return { ok: true, data: listRes.data || [] };
  } catch (err) {
    console.error('market_list error', err);
    return { ok: false, msg: err && err.message ? err.message : '服务端异常' };
  }
};