// cloudfunctions/post_create/index.js
const cloud = require('wx-server-sdk');
cloud.init({
  // env: '你的环境ID' // 可选，按需填写
});
const db = cloud.database();

exports.main = async (event, context) => {
  const now = Date.now();
  try {
    const openid = cloud.getWXContext().OPENID;
    const { title, content, images = [], board = 'default' } = event || {};

    // 基本校验
    if (!title || !content) {
      return { ok: false, msg: '标题或内容不能为空' };
    }
    if (typeof title !== 'string' || typeof content !== 'string') {
      return { ok: false, msg: '参数类型错误' };
    }
    // 限制长度（按需调整）
    if (title.length > 200) return { ok: false, msg: '标题过长' };
    if (content.length > 20000) return { ok: false, msg: '内容过长' };

    // images 应为 fileID 数组或 URL 数组；可为空
    const safeImages = Array.isArray(images) ? images.slice(0, 9) : [];

    const doc = {
      title,
      content,
      images: safeImages,
      board,
      status: 'published',
      like_count: 0,
      comment_count: 0,
      created_at: now,
      updated_at: now,
      openid
    };

    const addRes = await db.collection('posts').add({ data: doc });
    // 返回成功并包含新文档 id
    return { ok: true, data: { id: addRes._id } };
  } catch (err) {
    console.error('post_create error:', err);
    return { ok: false, msg: err && err.message ? err.message : '服务端错误' };
  }
};