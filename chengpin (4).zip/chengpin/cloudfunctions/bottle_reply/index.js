const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { bottle_id, content, images = [] } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!bottle_id || !content) return { ok: false, msg: '信息缺失' };

  try {
    const bottleRes = await db.collection('bottles').doc(bottle_id).get();
    const bottle = bottleRes.data;
    if (!bottle || bottle.status !== 'picked' || bottle.matched_openid !== openid) return { ok: false, msg: '无权回复' };
    await db.collection('bottle_msgs').add({
      data: {
        bottle_id,
        from_openid: openid,
        to_openid: bottle.openid,
        content, images, created_at: Date.now()
      }
    });
    await db.collection('bottles').doc(bottle_id).update({ data: { status: 'closed' } });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};