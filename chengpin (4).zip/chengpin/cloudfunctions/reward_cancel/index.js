const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { id, reason } = event;
  const openid = cloud.getWXContext().OPENID;

  try {
    const rewardRes = await db.collection('rewards').doc(id).get();
    const reward = rewardRes.data;
    if (!reward || reward.reward_status !== 'open' || reward.locker_openid !== openid) return { ok: false, msg: '不可取消' };

    // 退回积分
    await db.collection('rewards').doc(id).update({ data: { reward_status: 'canceled', cancel_reason: reason } });
    await db.collection('points_ledger').add({
      data: {
        openid,
        type: 'unlock',
        points: reward.reward_points,
        ref_type: 'reward',
        ref_id: id,
        created_at: Date.now()
      }
    });
    await db.collection('users').doc(openid).update({ data: { points_balance: db.command.inc(reward.reward_points) } });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};