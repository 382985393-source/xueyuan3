const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { id } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!id) return { ok: false, msg: '参数缺失' };

  try {
    const rewardRes = await db.collection('rewards').doc(id).get();
    const reward = rewardRes.data;
    if (!reward) return { ok: false, msg: '悬赏不存在' };

    // 权限判断
    let canAccept = reward.reward_status === 'open' && reward.locker_openid !== openid;
    let canDone = reward.reward_status === 'assigned' && reward.assigned_openid === openid;
    let canCancel = reward.reward_status === 'open' && reward.locker_openid === openid;

    return { ok: true, data: { reward, canAccept, canDone, canCancel } };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};