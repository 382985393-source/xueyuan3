function checkLogin(page) {
  const userInfo = wx.getStorageSync('userInfo');
  if (!userInfo) {
    // 记录当前页面路径和参数
    const pages = getCurrentPages();
    const current = pages[pages.length - 1];
    const { route, options } = current;
    // 拼接参数
    let paramStr = '';
    if (options && Object.keys(options).length > 0) {
      paramStr = '?' + Object.entries(options).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
    }
    // 存储跳转前的页面（用于登录后返回）
    wx.setStorageSync('redirectAfterLogin', `/${route}${paramStr}`);
    // 跳转登录页
    wx.redirectTo({ url: '/pages/login/login' });
    return false;
  }
  return true;
}
module.exports = { checkLogin };