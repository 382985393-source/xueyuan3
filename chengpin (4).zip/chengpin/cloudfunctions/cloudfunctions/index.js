const cloud = require('wx-server-sdk');

cloud.init(); // 如果需要指定环境可传 { env: 'cloud1-xxx' }

const db = cloud.database();

function makePost(school_id, board, title, suffix) {
  const now = Date.now();
  return {
    title: title || ('自动生成帖 ' + suffix),
    content: '这是测试自动生成的帖子 — ' + suffix,
    status: 'normal',
    school_id: school_id,
    board: board || 'gossip',
    author_id: null,
    author_nick: '系统',
    author_avatar: null,
    tags: ['自动'],
    images: [],
    created_at: now,
    published_at: now,
    fingerprint: `${school_id}::system::${now}::${Math.random().toString(36).slice(2,8)}`,
    meta: { source: 'system_auto_test' }
  };
}

exports.main = async (event) => {
  const count = Math.max(1, Math.min(20, event.count || 1)); // 最多20条，最少1条
  const school_id = (event.school_id !== undefined) ? event.school_id : 1;
  const board = event.board || 'gossip';

  const results = [];
  for (let i = 0; i < count; i++) {
    const doc = makePost(school_id, board, `系统帖 #${i+1}`, `#${i+1}`);
    // 单条写入
    // 注意：db.collection.add 返回各自结果
    try {
      const res = await db.collection('posts').add({ data: doc });
      results.push({ ok: true, id: res._id });
    } catch (e) {
      results.push({ ok: false, err: e.message || e });
    }
  }
  return { added: results.length, results };
};