const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const goods = db.collection('goods')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await goods.where(filter).orderBy('created_at', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await goods.doc(data.id).get()
  }
  if (action === 'delete') {
    await goods.doc(data.id).update({ data: { status: 'deleted' } })
    return { code: 0 }
  }
  if (action === 'edit') {
    await goods.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'up') {
    await goods.doc(data.id).update({ data: { status: 'up' } })
    return { code: 0 }
  }
  if (action === 'down') {
    await goods.doc(data.id).update({ data: { status: 'down' } })
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}