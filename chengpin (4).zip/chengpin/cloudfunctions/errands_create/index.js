const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { order_type, item, fee_estimate, contact, images = [], address_from, address_to } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!order_type || !item || !fee_estimate || !contact) return { ok: false, msg: '信息不完整' };
  try {
    const order = {
      order_type, item, fee_estimate, contact, images,
      order_status: 'open', pay_status: 'unpaid',
      created_at: Date.now(), openid
    };
    await db.collection('errands_orders').add({ data: order });
    return { ok: true, data: order };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};