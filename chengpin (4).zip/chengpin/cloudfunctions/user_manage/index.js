const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const users = db.collection('users')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await users.where(filter).orderBy('register_time', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await users.doc(data.id).get()
  }
  if (action === 'block') {
    await users.doc(data.id).update({ data: { status: 'blocked' } })
    return { code: 0 }
  }
  if (action === 'unblock') {
    await users.doc(data.id).update({ data: { status: 'active' } })
    return { code: 0 }
  }
  if (action === 'edit') {
    await users.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'delete') {
    await users.doc(data.id).update({ data: { status: 'deleted' } })
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}