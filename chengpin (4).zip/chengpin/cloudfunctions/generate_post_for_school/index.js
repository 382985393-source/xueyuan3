const cloud = require('wx-server-sdk');
const crypto = require('crypto');

cloud.init(); // 若你希望在特定 env 下运行，可改为 cloud.init({ env: 'your-env-id' });

const db = cloud.database();
const POSTS_COL = 'posts';

/**
 * 简单 fingerprint 函数
 */
function fingerprintOf(content) {
  return crypto.createHash('sha1').update(content).digest('hex');
}

/**
 * 生成单条内容（示例）
 * 你应替换为你真实的模板/内容生成逻辑
 */
function renderCandidate(templateId, idx) {
  // 示例内容，生产中替换为模板引擎输出
  const title = `系统测试帖 #${Date.now()}-${Math.floor(Math.random() * 10000)}-${idx}`;
  const body = `这是一条自动生成的测试帖（模板 ${templateId || 'default'}），时间 ${new Date().toISOString()}`;
  return { title, body };
}

exports.main = async (event = {}, context) => {
  const start = Date.now();
  try {
    // 接受多种命名（兼容触发器里你用 school_id 或 camelCase schoolId）
    const schoolId = event.schoolId || event.school_id || event.school || 'all';
    const templateId = event.templateId || event.template_id || null;
    const count = Number(event.count) || 1;
    const board = event.board || 'gossip';
    const forceOverwrite = !!event.forceOverwrite;

    const results = { created: [], skipped: [], updated: [], errors: [] };

    for (let i = 0; i < count; i++) {
      // 生成候选（请按你真实逻辑替换）
      const candidate = renderCandidate(templateId, i);
      const rawContent = `${candidate.title}\n${candidate.body}\nboard:${board}\nschool:${String(schoolId)}`;

      // 计算 fingerprint。若 forceOverwrite，则在 content 后追加时间扰动，保证 fingerprint 不相同，从而能插入新 doc。
      let fpBase = rawContent;
      if (forceOverwrite) {
        // 通过时间戳/随机数让 fingerprint 发生可控变化（避免覆盖）
        fpBase = `${rawContent}\nforce:${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
      }
      const fp = fingerprintOf(fpBase);

      // 检查是否已存在相同 fingerprint
      const existsRes = await db.collection(POSTS_COL).where({ fingerprint: fp }).limit(1).get();
      const exists = (existsRes && existsRes.data && existsRes.data.length) ? existsRes.data[0] : null;

      if (exists && !forceOverwrite) {
        // 不创建，记录 skipped（按原逻辑）
        results.skipped.push(exists._id || null);
        console.log('generatePostsForSchool: skipped existing fingerprint', fp, 'docId', exists._id);
        continue;
      }

      // 构造要写入的文档
      const doc = {
        title: candidate.title,
        content: candidate.body,
        fingerprint: fp,
        school_id: schoolId,
        board,
        status: 'normal',
        meta: { source: 'system_auto_test', generated_at: Date.now() },
        created_at: Date.now()
      };

      // 插入新文档
      try {
        const insertRes = await db.collection(POSTS_COL).add({ data: doc });
        results.created.push(insertRes._id || null);
        console.log('generatePostsForSchool: created docId', insertRes._id);
      } catch (err) {
        console.error('generatePostsForSchool: insert error', err);
        results.errors.push({ err: String(err), candidate: candidate.title });
      }
    }

    const took = Date.now() - start;
    const response = { ok: true, generate: { success: true, results, took } };
    console.log('generatePostsForSchool response:', JSON.stringify(response));
    return response;
  } catch (e) {
    console.error('generatePostsForSchool fatal error', e);
    return { ok: false, error: String(e) };
  }
};