const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (_, context) => {
  const openid = cloud.getWXContext().OPENID;
  try {
    const userRes = await db.collection('users').doc(openid).get();
    return { ok: true, data: userRes.data.points_balance || 0 };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};