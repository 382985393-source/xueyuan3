'use strict'
// posts_assign_school：把 meta.generated_by='post_auto_generate' 且没有 school_id 的帖子批量设为 school_id='all'
// 使用：在控制台云函数测试里传 { batchSize: 100 } 运行。先在少量数据上测试 single 模式。

const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const posts = db.collection('posts')
const _ = db.command

exports.main = async (event = {}) => {
  const batchSize = Math.min(100, Math.max(10, parseInt(event.batchSize || '100', 10)))
  const mode = event.mode || 'batch' // 'single' or 'batch'
  const now = new Date()

  try {
    if (mode === 'single') {
      const id = event.id
      if (!id) return { code: -1, msg: 'single mode requires id' }
      await posts.doc(id).update({ data: { school_id: 'all', school: '全校', updated_at: now, auto_note: 'assign school all' } })
      return { code: 0, id }
    }

    // batch mode: 查 meta.generated_by 且 school_id 不存在或为空
    let total = 0
    while (true) {
      // 注意：cloud db 不支持 exists(false) 在控制台时可用其它条件（依数据而定）
      // 这里查询 meta.generated_by='post_auto_generate' 且 (school_id == '' OR school_id == null OR school_id missing)
      const q = await posts.where({
        'meta.generated_by': 'post_auto_generate'
      }).limit(batchSize).get()
      const list = q.data || []
      if (!list.length) break

      for (const p of list) {
        // 如果已有且非空，跳过
        if (p.school_id && String(p.school_id).trim() !== '') continue
        try {
          await posts.doc(p._id).update({
            data: {
              school_id: 'all',
              school: '全校',
              updated_at: now,
              auto_note: 'assign school all'
            }
          })
          total++
        } catch (e) {
          console.warn('update fail', p._id, e.message || e)
        }
      }
      if (list.length < batchSize) break
    }

    return { code: 0, total }
  } catch (err) {
    console.error('posts_assign_school error', err)
    return { code: -1, msg: String(err) }
  }
}