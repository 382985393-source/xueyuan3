const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { content, images = [], tags = [] } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!content) return { ok: false, msg: '内容不能为空' };
  try {
    const now = Date.now();
    const bottle = {
      content, images, tags,
      created_at: now, openid,
      status: 'floating'
    };
    await db.collection('bottles').add({ data: bottle });
    return { ok: true, data: bottle };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};