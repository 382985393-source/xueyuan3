const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const config = db.collection('config')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'get') {
    // 获取配置项
    return await config.where(data.filter || {}).get()
  }
  if (action === 'edit') {
    // 修改配置项（如公告、轮播图等）
    await config.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'add') {
    await config.add({ data: data })
    return { code: 0 }
  }
  if (action === 'delete') {
    await config.doc(data.id).remove()
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}