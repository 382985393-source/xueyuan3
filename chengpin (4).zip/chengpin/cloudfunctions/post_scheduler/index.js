// 精简版 post_scheduler（无外部依赖）
// 作用：读取 config.auto_generate 配置并调用 post_auto_generate（云函数间调用），或处理 scheduled_publish_time 到点的帖子
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const now = new Date()
  try {
    // 读取 config.auto_generate（可在控制台 config 集合里插入 key=auto_generate 的配置）
    const cfgQ = await db.collection('config').where({ key: 'auto_generate' }).limit(1).get()
    const cfgDoc = (cfgQ.data && cfgQ.data[0]) || null
    const cfg = cfgDoc && cfgDoc.value

    if (cfg && cfg.enableGenerate) {
      const categories = cfg.categories || []
      const results = []
      for (const c of categories) {
        try {
          const res = await cloud.callFunction({
            name: 'post_auto_generate',
            data: {
              category: c.name,
              count: c.count || 1,
              author_id: c.author_id || 'system',
              author_nick: c.author_nick || '系统自动'
            }
          })
          results.push({ category: c.name, result: res.result || res })
        } catch (e) {
          console.error('call post_auto_generate failed', c.name, e)
          results.push({ category: c.name, error: String(e) })
        }
      }
      return { code: 0, mode: 'generate', results }
    }

    // 否则处理 scheduled_publish_time 到点的帖子
    const q = await db.collection('posts')
      .where({
        status: 'pending',
        scheduled_publish_time: _.lte(now)
      })
      .limit(100)
      .get()
    const list = q.data || []
    const processed = []
    for (const p of list) {
      try {
        await db.collection('posts').doc(p._id).update({
          data: {
            status: 'normal',
            published_at: now,
            published_by: 'scheduler',
            auto_reason: '定时发布'
          }
        })
        processed.push(p._id)
      } catch (e) {
        console.warn('publish fail', p._id, e)
      }
    }
    return { code: 0, mode: 'scheduled_publish', processed }
  } catch (err) {
    console.error('post_scheduler error', err)
    return { code: -1, msg: String(err) }
  }
}