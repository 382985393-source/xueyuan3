'use strict'
// post_auto_generate - 模板自动生成帖子并强制直接发布（为全校通用）
// 本版本关键变更：插入的帖子包含 school_id:'all' 与 school:'全校'；同时规范 author_id 为 "system"（trim）。
// 环境变量：AUTO_PUBLISH, FORCE_PUBLISH, MODERATION, MAX_GENERATE
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const posts = db.collection('posts')

// 环境变量读取（默认值）
const ENV = process.env || {}
const AUTO_PUBLISH = (ENV.AUTO_PUBLISH || 'true').toLowerCase() === 'true'
const ENV_FORCE_PUBLISH = (ENV.FORCE_PUBLISH || 'false').toLowerCase() === 'true'
const MODERATION = (ENV.MODERATION || 'true').toLowerCase() === 'true'
const MAX_GENERATE = Math.min(10, Math.max(1, parseInt(ENV.MAX_GENERATE || '3', 10)))

// 简单敏感词（生产请替换为微信/腾讯安全或第三方）
const SENSITIVE_WORDS = ['敏感词A', '敏感词B']
function hasSensitive(text) {
  if (!text) return false
  return SENSITIVE_WORDS.some(w => text && text.indexOf(w) !== -1)
}

// 后备模板生成（覆盖你列出的板块）
function templateGenerate(category) {
  const nowStr = new Date().toLocaleString()
  const k = (category || '').toLowerCase()
  if (k.includes('吐槽') || k === 'tucao') {
    return { title: `今日吐槽 · ${nowStr}`, content: `又到吐槽时间：今天遇到的事情是...（系统自动生成）` }
  }
  if (k.includes('告白')) {
    return { title: `悄悄告白 · ${nowStr}`, content: `在这个特别的时刻，我想对你说...（系统自动生成）` }
  }
  if (k.includes('纸条') || k.includes('传纸条')) {
    return { title: `纸条 · ${nowStr}`, content: `悄悄放一张纸条：你有没有注意到...（系统自动生成）` }
  }
  if (k.includes('任务')) {
    return { title: `任务发布：帮个忙 · ${nowStr}`, content: `需要人帮忙：帮忙取快递/打印等，酬劳可议（系统自动生成）` }
  }
  if (k.includes('游戏') || k.includes('交友')) {
    return { title: `活动/交友：快来参与 · ${nowStr}`, content: `组织一个小游戏/交友活动：详情见评论（系统自动生成）` }
  }
  if (k.includes('闲置') || k.includes('市场')) {
    return { title: `闲置转让 · ${nowStr}`, content: `转让物品：成色良好，价格可议（系统自动生成）` }
  }
  if (k.includes('失物') || k.includes('招领')) {
    return { title: `失物招领 · ${nowStr}`, content: `捡到/丢失物品：请私信联系（系统自动生成）` }
  }
  if (k.includes('招聘')) {
    return { title: `招聘信息 · ${nowStr}`, content: `诚聘人员：兼职/全职岗位若干，欢迎投简历（系统自动生成）` }
  }
  return { title: `${category || '综合'} 自动帖 · ${nowStr}`, content: `这是系统在 ${category || '综合'} 板块自动生成的内容（模板）。` }
}

exports.main = async (event = {}, context) => {
  const {
    category = '综合',
    count = 1,
    author_id: rawAuthorId,
    author_nick: rawAuthorNick,
    author_avatar = '',
    forcePublish = false
  } = event

  // 规范 author_id / author_nick，确保没有前后空格并有默认值
  let author_id = typeof rawAuthorId === 'string' ? rawAuthorId.trim() : (rawAuthorId ? String(rawAuthorId) : 'system')
  if (!author_id) author_id = 'system'
  const author_nick = (typeof rawAuthorNick === 'string' ? rawAuthorNick.trim() : (rawAuthorNick ? String(rawAuthorNick) : '系统自动')) || '系统自动'

  const n = Math.min(MAX_GENERATE, Math.max(1, parseInt(count || 1, 10)))
  const now = new Date()
  const createdResults = []

  try {
    for (let i = 0; i < n; i++) {
      const gen = templateGenerate(category)
      const textForCheck = `${gen.title}\n${gen.content}`

      // 审查（内置简单敏感词）
      const flagged = MODERATION && hasSensitive(textForCheck)

      // 发布决定： event.forcePublish > ENV_FORCE_PUBLISH > AUTO_PUBLISH & !flagged
      const shouldForce = !!forcePublish || ENV_FORCE_PUBLISH
      const shouldPublish = shouldForce ? true : (AUTO_PUBLISH && !flagged)

      // 构造文档：关键字段 school_id='all'，school='全校'
      const doc = {
        type: category,
        title: gen.title,
        content: gen.content,
        author_id,
        author_nick,
        author_avatar,
        images: [],
        created_at: now,
        likes: 0,
        views: 0,
        is_top: false,
        // 全校通用标记
        school_id: 'all',
        school: '全校',
        status: shouldPublish ? 'normal' : 'pending', // 发布用 normal，不用 done
        scheduled_publish_time: null,
        published_at: shouldPublish ? now : null,
        published_by: shouldPublish ? 'auto' : null,
        auto_reason: flagged ? '自动生成-触发审查' : (shouldForce ? '强制自动发布' : '自动生成'),
        meta: {
          generated_by: 'post_auto_generate',
          generator: 'template',
          force_publish: shouldForce
        }
      }

      const res = await posts.add({ data: doc })
      createdResults.push({ id: res._id, status: doc.status, flagged, force: shouldForce })
    }

    return { code: 0, created: createdResults, note: 'post_auto_generate executed' }
  } catch (err) {
    console.error('post_auto_generate error', err)
    return { code: -1, msg: String(err) }
  }
}