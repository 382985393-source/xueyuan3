const cloud = require('wx-server-sdk');
cloud.init({
  // env: '你的环境ID' // 根据需要填写或留空使用当前环境
});
const db = cloud.database();
const cmd = db.command;

const AUTO_CREATE_USER_IF_NOT_FOUND = true; // 改为 false 则不会自动建用户

// 安全查用户：按多种字段查找（_id / _openid / openid），不会抛异常
async function findUserByIdOrOpenid(id) {
  if (!id) return null;
  // 按 _id 查
  try {
    let res = await db.collection('users').where({ _id: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {
    console.warn('findUserByIdOrOpenid _id check failed', e && e.message);
  }

  // 按系统字段 _openid 查（有的项目会保存）
  try {
    let res = await db.collection('users').where({ _openid: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {
    // 某些环境下对 _openid 的 where 可能会有权限限制，忽略异常
    console.warn('findUserByIdOrOpenid _openid check failed', e && e.message);
  }

  // 按自定义 openid 字段查（如果你在 users 文档里保存了 openid）
  try {
    let res = await db.collection('users').where({ openid: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {
    console.warn('findUserByIdOrOpenid openid check failed', e && e.message);
  }

  return null;
}

exports.main = async (event, context) => {
  const now = Date.now();
  try {
    console.log('reward_create incoming event:', event);
    const wxContext = cloud.getWXContext();
    const requestOpenid = wxContext.OPENID;
    console.log('requestOpenid:', requestOpenid);

    // 兼容前端字段名
    const title = (event.title || '').trim();
    const description = (event.description || event.content || '').trim();
    const reward_points = Number(event.reward_points || event.points || 0);
    const lockerId = event.locker_id || requestOpenid; // 前端可传 locker_id，否则使用当前用户

    if (!title) return { ok: false, code: 'BAD_REQUEST', msg: '标题不能为空' };
    if (!description) return { ok: false, code: 'BAD_REQUEST', msg: '悬赏描述不能为空' };
    if (!Number.isFinite(reward_points) || reward_points <= 0) return { ok: false, code: 'BAD_REQUEST', msg: '悬赏积分必须为正整数' };

    console.log('trying to find locker user by id/openid:', lockerId);
    let locker = await findUserByIdOrOpenid(lockerId);

    if (!locker) {
      console.warn('locker not found for id:', lockerId);
      if (AUTO_CREATE_USER_IF_NOT_FOUND) {
        // 自动创建最小用户记录（可自定义初始积分）
        const initialPoints = 0; // 默认新用户积分为 0，可按需修改
        const newUser = {
          // 不强制设置 _id，让 DB 自动生成 _id；保存传入的 openid 到 openid 字段
          openid: String(lockerId),
          points_balance: initialPoints,
          created_at: now,
          updated_at: now
        };
        const addRes = await db.collection('users').add({ data: newUser });
        console.log('auto-created user, new _id:', addRes._id);
        // 读取刚创建的用户记录
        const created = await db.collection('users').where({ _id: addRes._id }).limit(1).get();
        locker = (created.data && created.data[0]) || { _id: addRes._id, points_balance: initialPoints, openid: lockerId };
        // 如果新用户积分不足以发布悬赏，直接返回提示（并不回滚，因为没有扣分）
        if ((Number(locker.points_balance) || 0) < reward_points) {
          return { ok: false, code: 'INSUFFICIENT_BALANCE', msg: `积分不足：当前余额 ${(Number(locker.points_balance)||0)}，需要 ${reward_points}` };
        }
      } else {
        const msg = `locker 用户不存在: ${lockerId}`;
        console.warn(msg);
        return { ok: false, code: 'NOT_FOUND', msg };
      }
    } else {
      console.log('found locker user _id:', locker._id, 'points_balance:', locker.points_balance);
    }

    // 再次确认余额
    const balance = Number(locker.points_balance || 0);
    if (balance < reward_points) {
      return { ok: false, code: 'INSUFFICIENT_BALANCE', msg: `积分不足：当前余额 ${balance}，需要 ${reward_points}` };
    }

    // 写 rewards
    const rewardDoc = {
      title,
      description,
      reward_points,
      locker_openid: locker._id || locker.openid || lockerId,
      reward_status: 'open',
      created_at: now,
      updated_at: now,
      due_at: event.due_at || null,
      assigned_openid: null
    };
    const addRes = await db.collection('rewards').add({ data: rewardDoc });
    const rewardId = addRes._id;
    console.log('reward created id:', rewardId);

    // 扣除积分并写流水（原子）
    await db.collection('users').doc(locker._id).update({
      data: { points_balance: cmd.inc(-Math.abs(reward_points)) }
    });

    await db.collection('points_ledger').add({
      data: {
        openid: locker._id,
        type: 'lock',
        points: -Math.abs(reward_points),
        ref_type: 'reward',
        ref_id: rewardId,
        created_at: now
      }
    });

    console.log('reward_create success rewardId:', rewardId);
    return { ok: true, data: { rewardId }, msg: '悬赏发布成功' };
  } catch (err) {
    console.error('reward_create error:', err && err.message ? err.message : err);
    return { ok: false, code: 'SERVER_ERROR', msg: err && err.message ? err.message : '服务端异常' };
  }
};