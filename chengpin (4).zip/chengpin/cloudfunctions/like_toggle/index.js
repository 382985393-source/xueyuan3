const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { target_type, id } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!target_type || !id) return { ok: false, msg: '参数缺失' };

  const likes = db.collection('likes');
  try {
    const exist = await likes.where({ target_type, target_id: id, openid }).get();
    if (exist.data.length) {
      // 取消点赞
      await likes.where({ target_type, target_id: id, openid }).remove();
      return { ok: true, data: { liked: false } };
    } else {
      // 点赞
      await likes.add({ data: { target_type, target_id: id, openid, created_at: Date.now() } });
      return { ok: true, data: { liked: true } };
    }
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};