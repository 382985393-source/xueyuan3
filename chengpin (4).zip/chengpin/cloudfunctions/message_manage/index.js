const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const messages = db.collection('messages')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await messages.where(filter).orderBy('created_at', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await messages.doc(data.id).get()
  }
  if (action === 'add') {
    await messages.add({ data: data })
    return { code: 0 }
  }
  if (action === 'edit') {
    await messages.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'delete') {
    await messages.doc(data.id).remove()
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}