const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { post_id, content, images = [] } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!post_id || !content) return { ok: false, msg: '参数缺失' };

  // 敏感词检测可预留，这里直接通过
  try {
    await db.collection('comments').add({
      data: {
        post_id,
        content,
        images,
        openid,
        status: 'approved', // 可改为 pending
        created_at: Date.now()
      }
    });
    await db.collection('posts').doc(post_id).update({
      data: { comments: db.command.inc(1) }
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};