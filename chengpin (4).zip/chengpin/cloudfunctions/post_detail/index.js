const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { id } = event;
  if (!id) return { ok: false, msg: '参数缺失' };

  try {
    const postRes = await db.collection('posts').doc(id).get();
    if (!postRes.data || postRes.data.status !== 'ok') return { ok: false, msg: '帖子不存在' };

    const commentsRes = await db.collection('comments').where({ post_id: id, status: 'approved' }).orderBy('created_at', 'asc').get();

    // 简单点赞判断
    const openid = cloud.getWXContext().OPENID;
    const likeRes = await db.collection('likes').where({ target_type: 'post', target_id: id, openid }).count();
    const liked = likeRes.total > 0;

    return {
      ok: true,
      data: {
        post: postRes.data,
        comments: commentsRes.data,
        liked
      }
    };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};