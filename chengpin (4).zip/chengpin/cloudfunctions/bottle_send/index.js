const cloud = require('wx-server-sdk')
cloud.init()

exports.main = async (event, context) => {
  const db = cloud.database()
  const { content } = event
  const { OPENID } = cloud.getWXContext()
  if (!content || !OPENID) {
    return { success: false, message: '内容或用户信息缺失' }
  }
  try {
    await db.collection('bottles').add({
      data: {
        content,
        time: new Date(),
        user: OPENID
      }
    })
    return { success: true, message: '纸条发送成功' }
  } catch (e) {
    return { success: false, message: '发送失败', error: e }
  }
}