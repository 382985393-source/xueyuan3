const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const wallet = db.collection('wallet')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await wallet.where(filter).orderBy('created_at', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await wallet.doc(data.id).get()
  }
  if (action === 'add') {
    await wallet.add({ data: data })
    return { code: 0 }
  }
  if (action === 'edit') {
    await wallet.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'delete') {
    await wallet.doc(data.id).remove()
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}