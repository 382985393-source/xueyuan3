const cloud = require('wx-server-sdk');
const crypto = require('crypto');

// 显式使用动态环境，避免“当前未指定env，将默认使用第一个创建的环境！”的提示
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

const db = cloud.database();
const cmd = db.command;

/**
 * 为单个学校生成自动贴（日级别幂等）
 * @param {string} schoolId
 * @param {string|null} templateId
 * @param {boolean} forceOverwrite
 */
async function generatePostsForSchool(schoolId = '', templateId = null, forceOverwrite = false) {
  const start = Date.now();
  // 简单模板池（可改为 db.collection('templates')）
  const TEMPLATES = [
    { id: 't1', title: (s) => `本周校园热点（${s}）`, content: (s) => `大家好，欢迎关注 ${s} 的本周热点……` },
    { id: 't2', title: (s) => `${s} 每日速报`, content: (s) => `这是 ${s} 的每日要点：……` },
  ];

  const templates = templateId ? TEMPLATES.filter(t => t.id === templateId) : TEMPLATES;
  if (!templates.length) {
    const msg = `no templates for templateId=${templateId}`;
    console.warn('generatePostsForSchool:', msg);
    return { success: false, message: msg };
  }

  const results = { created: [], skipped: [], updated: [], errors: [] };
  const dateKey = (new Date()).toISOString().slice(0, 10); // YYYY-MM-DD

  for (const tpl of templates) {
    try {
      const title = tpl.title(schoolId || '全校');
      const content = tpl.content(schoolId || '全校');

      const fingerprint = crypto.createHash('sha1').update(`${schoolId}::${tpl.id}::${dateKey}`).digest('hex');

      // 幂等检查：按 fingerprint 去重
      const exist = await db.collection('posts').where({ fingerprint }).limit(1).get();
      if (exist && exist.data && exist.data.length > 0) {
        const doc = exist.data[0];
        if (forceOverwrite) {
          await db.collection('posts').doc(doc._id).update({
            data: {
              title,
              content,
              updated_at: Date.now(),
              published_at: Date.now(),
              status: 'normal'
            }
          });
          results.updated.push(doc._id);
          console.log('generatePostsForSchool: updated existing post', doc._id);
        } else {
          results.skipped.push(doc._id);
          console.log('generatePostsForSchool: skipped existing fingerprint', fingerprint, 'docId', doc._id);
        }
        continue;
      }

      // 插入新帖子
      const newDoc = {
        title,
        content,
        status: 'normal',
        school_id: schoolId || 'all',
        author_id: 'system',
        author_nick: '系统自动',
        fingerprint,
        created_at: Date.now(),
        published_at: Date.now(),
        meta: { templateId: tpl.id, generatedBy: 'agg_daily.generatePostsForSchool' }
      };

      const insertRes = await db.collection('posts').add({ data: newDoc });
      if (insertRes && insertRes._id) {
        results.created.push(insertRes._id);
        console.log('generatePostsForSchool: created post', insertRes._id, 'school', schoolId || 'all');
      } else {
        results.errors.push({ template: tpl.id, error: 'no _id returned' });
        console.error('generatePostsForSchool: insert returned no _id', insertRes);
      }
    } catch (err) {
      console.error('generatePostsForSchool: error processing template', tpl.id, err && err.message ? err.message : err);
      results.errors.push({ template: tpl.id, error: String(err) });
    }
  }

  const took = Date.now() - start;
  return { success: true, results, took };
}

/**
 * agg_daily 云函数主入口
 * - 当传入 event.school_id 时：先触发为该学校生成自动贴（并返回生成结果）
 * - 否则保持原本的汇总/过期悬赏处理逻辑
 */
exports.main = async (event, context) => {
  const now = Date.now();

  // 如果调用方传入 school_id，则优先做单校生成并返回结果
  if (event && Object.prototype.hasOwnProperty.call(event, 'school_id')) {
    const schoolId = event.school_id === null ? '' : String(event.school_id || '');
    const templateId = event.templateId || null;
    const forceOverwrite = !!event.forceOverwrite;
    console.log('agg_daily: invoked generatePostsForSchool', { schoolId, templateId, forceOverwrite });
    try {
      const genRes = await generatePostsForSchool(schoolId, templateId, forceOverwrite);
      return { ok: true, generate: genRes };
    } catch (err) {
      console.error('agg_daily: generatePostsForSchool fatal error', err && err.message ? err.message : err);
      return { ok: false, msg: String(err) };
    }
  }

  // 原有的 agg_daily 行为（处理过期悬赏 + 日汇总）
  try {
    // 1) 处理过期悬赏（分批）
    let expiredCount = 0;
    const pageSize = 100;
    let page = 0;

    while (true) {
      const res = await db.collection('rewards')
        .where({
          due_at: cmd.lt(now),
          reward_status: 'open'
        })
        .orderBy('created_at', 'asc')
        .skip(page * pageSize)
        .limit(pageSize)
        .get();

      const list = res.data || [];
      if (!list.length) break;

      for (const r of list) {
        try {
          await db.collection('rewards').doc(r._id).update({
            data: {
              reward_status: 'expired',
              expired_at: now
            }
          });

          await db.collection('points_ledger').add({
            data: {
              openid: r.locker_openid,
              type: 'unlock',
              points: r.reward_points,
              ref_type: 'reward',
              ref_id: r._id,
              created_at: now
            }
          });

          await db.collection('users').doc(r.locker_openid).update({
            data: {
              points_balance: cmd.inc(r.reward_points)
            }
          });

          expiredCount++;
        } catch (innerErr) {
          console.error(`agg_daily: process reward ${r._id} failed:`, innerErr && innerErr.message ? innerErr.message : innerErr);
        }
      }

      if (list.length < pageSize) break;
      page++;
    }

    // 2) 日汇总示例（统计当天）
    const startOfDay = new Date(now);
    startOfDay.setHours(0, 0, 0, 0);
    const startTs = startOfDay.getTime();
    const dayStr = startOfDay.getFullYear() + '-' +
      String(startOfDay.getMonth() + 1).padStart(2, '0') + '-' +
      String(startOfDay.getDate()).padStart(2, '0');

    // counts (使用 count() API)
    const postsCountRes = await db.collection('posts').where({ created_at: cmd.gte(startTs) }).count();
    const postsCount = postsCountRes.total || 0;

    const rewardsDoneRes = await db.collection('rewards').where({
      reward_status: 'done',
      created_at: cmd.gte(startTs)
    }).count();
    const rewardsDone = rewardsDoneRes.total || 0;

    const errandsDoneRes = await db.collection('errands_orders').where({
      order_status: 'done',
      created_at: cmd.gte(startTs)
    }).count();
    const errandsDone = errandsDoneRes.total || 0;

    const newUsersRes = await db.collection('users').where({
      created_at: cmd.gte(startTs)
    }).count();
    const newUsers = newUsersRes.total || 0;

    const metrics = {
      day: dayStr,
      ts: now,
      posts: postsCount,
      rewards_done: rewardsDone,
      errands_done: errandsDone,
      new_users: newUsers,
      expired_rewards_processed: expiredCount
    };

    // upsert metrics_daily (更新或插入)
    const existed = await db.collection('metrics_daily').where({ day: dayStr }).get();
    if (existed.data && existed.data.length) {
      await db.collection('metrics_daily').doc(existed.data[0]._id).update({
        data: metrics
      });
    } else {
      await db.collection('metrics_daily').add({ data: metrics });
    }

    return { ok: true, data: { expiredCount, metrics } };
  } catch (err) {
    console.error('agg_daily error:', err && err.message ? err.message : err);
    return { ok: false, msg: err && err.message ? err.message : String(err) };
  }
};