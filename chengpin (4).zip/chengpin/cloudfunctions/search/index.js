const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { keyword, page = 1, pageSize = 10 } = event;
  if (!keyword) return { ok: false, msg: '关键词不能为空' };

  try {
    const res = await db.collection('posts')
      .where({
        status: 'ok',
        title: db.RegExp({ regexp: keyword, options: 'i' })
      })
      .orderBy('created_at', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();
    return { ok: true, data: res.data };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};