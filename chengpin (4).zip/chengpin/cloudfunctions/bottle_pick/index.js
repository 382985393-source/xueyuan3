const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const openid = cloud.getWXContext().OPENID;
  try {
    // 随机捞一个
    const res = await db.collection('bottles').where({ status: 'floating', openid: db.command.neq(openid) }).limit(20).get();
    if (!res.data.length) return { ok: false, msg: '无可捞瓶子' };
    const pick = res.data[Math.floor(Math.random() * res.data.length)];
    await db.collection('bottles').doc(pick._id).update({
      data: { status: 'picked', matched_openid: openid }
    });
    return { ok: true, data: pick };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};