const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { page = 1, pageSize = 10 } = event;
  try {
    const res = await db.collection('point_goods')
      .where({ status: 'on' })
      .orderBy('sort', 'asc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();
    return { ok: true, data: res.data };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};