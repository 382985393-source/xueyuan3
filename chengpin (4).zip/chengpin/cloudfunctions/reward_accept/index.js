const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { id } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!id) return { ok: false, msg: '参数缺失' };

  try {
    const rewardRes = await db.collection('rewards').doc(id).get();
    const reward = rewardRes.data;
    if (!reward || reward.reward_status !== 'open') return { ok: false, msg: '不可接单' };
    if (reward.locker_openid === openid) return { ok: false, msg: '不能接自己的单' };

    await db.collection('rewards').doc(id).update({
      data: { assigned_openid: openid, reward_status: 'assigned' }
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};