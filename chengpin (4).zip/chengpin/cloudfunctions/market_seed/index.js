const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  try {
    const now = Date.now();
    const items = [
      { title: '二手书：《JavaScript 权威指南》', description: '成色良好，9成新', price: 30, stock: 2, cover: '/assets/boards/market.svg', created_at: now },
      { title: '耳机（有线）', description: '备用耳机，功能正常', price: 50, stock: 3, cover: '/assets/boards/market.svg', created_at: now },
      { title: '笔记本支架', description: '便携可折叠', price: 20, stock: 5, cover: '/assets/boards/market.svg', created_at: now },
      { title: '手机壳', description: '全包硅胶', price: 10, stock: 10, cover: '/assets/boards/market.svg', created_at: now },
      { title: '文具礼包', description: '多种学习用品', price: 15, stock: 6, cover: '/assets/boards/market.svg', created_at: now }
    ];

    const insertPromises = items.map(it => db.collection('market_items').add({ data: it }));
    const results = await Promise.all(insertPromises);
    return { ok: true, data: results, msg: '已插入示例商品' };
  } catch (err) {
    console.error('market_seed error', err);
    return { ok: false, msg: err && err.message ? err.message : '服务异常' };
  }
};