const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event) => {
  const { status, page = 1, pageSize = 10 } = event;
  let cond = {};
  if (status) cond.order_status = status;
  try {
    const res = await db.collection('errands_orders')
      .where(cond)
      .orderBy('created_at', 'desc')
      .skip((page - 1) * pageSize)
      .limit(pageSize)
      .get();
    return { ok: true, data: res.data };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};