const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { id, proof } = event;
  const openid = cloud.getWXContext().OPENID;

  try {
    const rewardRes = await db.collection('rewards').doc(id).get();
    const reward = rewardRes.data;
    if (!reward || reward.reward_status !== 'assigned' || reward.assigned_openid !== openid) return { ok: false, msg: '无权操作' };

    // 发放积分
    await db.collection('rewards').doc(id).update({ data: { reward_status: 'done', proof } });
    await db.collection('points_ledger').add({
      data: {
        openid: reward.assigned_openid,
        type: 'award',
        points: reward.reward_points,
        ref_type: 'reward',
        ref_id: id,
        created_at: Date.now()
      }
    });
    // 扣减发布者余额（锁转实扣），加接单者余额
    await db.collection('users').doc(reward.locker_openid).update({ data: { points_balance: db.command.inc(-reward.reward_points) } });
    await db.collection('users').doc(reward.assigned_openid).update({ data: { points_balance: db.command.inc(reward.reward_points) } });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};