const cloud = require('wx-server-sdk')
cloud.init()

exports.main = async (event, context) => {
  const db = cloud.database()
  const { OPENID } = cloud.getWXContext()

  // 随机取一条不属于自己的纸条
  try {
    // 获取总数
    const countRes = await db.collection('bottles').where({
      user: db.command.neq(OPENID)
    }).count()
    const total = countRes.total
    if (total === 0) {
      return { success: false, message: '暂无可接收纸条' }
    }
    // 随机跳页
    const randomIndex = Math.floor(Math.random() * total)
    const res = await db.collection('bottles').where({
      user: db.command.neq(OPENID)
    }).skip(randomIndex).limit(1).get()
    if (res.data.length === 0) {
      return { success: false, message: '暂无可接收纸条' }
    }
    return { success: true, content: res.data[0].content }
  } catch (e) {
    return { success: false, message: '接收失败', error: e }
  }
}