const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();

exports.main = async (event, context) => {
  const { points } = event;
  const openid = cloud.getWXContext().OPENID;
  if (!points || points < 1) return { ok: false, msg: '积分无效' };
  try {
    await db.collection('points_ledger').add({
      data: {
        openid,
        type: 'recharge',
        points,
        ref_type: 'recharge',
        ref_id: '',
        created_at: Date.now(),
        status: 'pending'
      }
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
};