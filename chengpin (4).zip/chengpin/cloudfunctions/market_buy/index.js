const cloud = require('wx-server-sdk');
cloud.init();
const db = cloud.database();
const cmd = db.command;

// 安全查用户（兼容 _id/_openid/openid）
async function findUserByIdOrOpenid(id) {
  if (!id) return null;
  try {
    let res = await db.collection('users').where({ _id: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {}
  try {
    let res = await db.collection('users').where({ _openid: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {}
  try {
    let res = await db.collection('users').where({ openid: String(id) }).limit(1).get();
    if (res.data && res.data.length) return res.data[0];
  } catch (e) {}
  return null;
}

async function getItemById(id) {
  const res = await db.collection('market_items').where({ _id: id }).limit(1).get();
  return (res.data && res.data.length) ? res.data[0] : null;
}

exports.main = async (event, context) => {
  const now = Date.now();
  try {
    const wxContext = cloud.getWXContext();
    const buyerOpenid = wxContext.OPENID;
    const itemId = event.itemId;
    const quantity = Number(event.quantity || 1);

    if (!itemId) return { ok: false, msg: '参数错误' };
    if (quantity <= 0) return { ok: false, msg: '数量错误' };

    const buyer = await findUserByIdOrOpenid(buyerOpenid);
    if (!buyer) return { ok: false, msg: '买家用户不存在' };

    const item = await getItemById(itemId);
    if (!item) return { ok: false, msg: '商品不存在' };
    if ((item.stock || 0) < quantity) return { ok: false, msg: '库存不足' };

    const totalPrice = Number(item.price || 0) * quantity;
    const balance = Number(buyer.points_balance || 0);
    if (balance < totalPrice) return { ok: false, msg: `积分不足，当前 ${balance}` };

    // 扣减用户积分 & 扣库存 & 写订单 & 写积分流水
    // 执行顺序：更新用户 -> 更新商品库存 -> 写订单 -> 写 points_ledger
    await db.collection('users').doc(buyer._id).update({
      data: { points_balance: cmd.inc(-totalPrice) }
    });

    await db.collection('market_items').doc(item._id).update({
      data: { stock: cmd.inc(-quantity) }
    });

    const order = {
      buyer_openid: buyer._id,
      item_id: item._id,
      quantity,
      total_price: totalPrice,
      status: 'done',
      created_at: now
    };
    const orderRes = await db.collection('market_orders').add({ data: order });

    await db.collection('points_ledger').add({
      data: {
        openid: buyer._id,
        type: 'spend',
        points: -totalPrice,
        ref_type: 'market',
        ref_id: orderRes._id,
        created_at: now
      }
    });

    return { ok: true, data: { orderId: orderRes._id }, msg: '购买成功' };
  } catch (err) {
    console.error('market_buy error', err);
    return { ok: false, msg: err && err.message ? err.message : '服务异常' };
  }
};