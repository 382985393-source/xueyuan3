const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const feedback = db.collection('feedback')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await feedback.where(filter).orderBy('created_at', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await feedback.doc(data.id).get()
  }
  if (action === 'edit') {
    await feedback.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'delete') {
    await feedback.doc(data.id).remove()
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}