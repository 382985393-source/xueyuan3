const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()
const orders = db.collection('orders')

exports.main = async (event, context) => {
  const { action, data } = event

  if (action === 'list') {
    let { filter = {}, skip = 0, limit = 20 } = data || {}
    return await orders.where(filter).orderBy('created_at', 'desc').skip(skip).limit(limit).get()
  }
  if (action === 'get') {
    return await orders.doc(data.id).get()
  }
  if (action === 'delete') {
    await orders.doc(data.id).update({ data: { status: 'cancelled' } })
    return { code: 0 }
  }
  if (action === 'edit') {
    await orders.doc(data.id).update({ data: data.update })
    return { code: 0 }
  }
  if (action === 'pay') {
    await orders.doc(data.id).update({ data: { status: 'paid' } })
    return { code: 0 }
  }
  if (action === 'ship') {
    await orders.doc(data.id).update({ data: { status: 'shipped' } })
    return { code: 0 }
  }
  return { code: -1, msg: '未知操作' }
}