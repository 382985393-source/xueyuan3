const boardsUtil = require('../../utils/boards');
Page({
  data: { items: [] },
  onLoad() {
    const board = boardsUtil.findById('jobs') || {};
    const items = Array.from({ length: 9 }).map((_, i) => ({
      _id: 'jobs_' + i,
      title: `${board.name || '兼职'} 示例 ${i+1}`,
      emoji: board.emoji || '💼',
      gradient: board.gradient || 'background: linear-gradient(135deg,#f6d365,#fda085);'
    }));
    this.setData({ items });
  }
});