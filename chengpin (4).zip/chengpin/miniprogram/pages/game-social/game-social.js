const GAME_LIST = [
  { key: "all", name: "全部" },
  { key: "wangzhe", name: "王者荣耀" },
  { key: "lol", name: "英雄联盟" },
  { key: "yuanshen", name: "原神" },
  { key: "pubg", name: "和平精英" }
];
Page({
  data: {
    school: {},
    gameTabs: GAME_LIST,
    activeGame: "all",
    teamList: [],
    showPopup: false,
    form: {
      game: "",
      gameKey: "",
      desc: "",
      level: "",
      contact: "",
      time: "",
      anonymous: true
    }
  },
  onShow() {
    // 校验school_id
    let user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    this.setData({ school: { id: user.school_id, name: user.school_name } });
    this.loadTeams();
  },
  loadTeams() {
    let { activeGame, school } = this.data;
    let all = wx.getStorageSync('gameTeams') || [];
    // 过滤本校
    let list = all.filter(item =>
      (activeGame === 'all' || item.gameKey === activeGame) &&
      item.school_id === school.id &&
      (!item.expireAt || item.expireAt > Date.now())
    );
    // 按时间倒序
    list.sort((a, b) => b.time - a.time);
    this.setData({ teamList: list });
  },
  onTabChange(e) {
    this.setData({ activeGame: e.currentTarget.dataset.key }, this.loadTeams);
  },
  openPopup() {
    this.setData({
      showPopup: true,
      form: {
        game: "",
        gameKey: "",
        desc: "",
        level: "",
        contact: "",
        time: "",
        anonymous: true
      }
    });
  },
  closePopup() {
    this.setData({ showPopup: false });
  },
  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`form.${field}`]: e.detail.value });
  },
  // 修正：picker选择游戏后正确赋值
  onGameSelect(e) {
    const idx = e.detail.value;
    const gameTabs = this.data.gameTabs;
    this.setData({
      'form.game': gameTabs[idx].name,
      'form.gameKey': gameTabs[idx].key
    });
  },
  toggleAnonymous(e) {
    this.setData({ 'form.anonymous': e.detail.value });
  },
  submitTeam() {
    const { game, desc, level, contact, time, anonymous, gameKey } = this.data.form;
    if (!game || !desc || !contact) {
      wx.showToast({ title: '必填项不能为空', icon: 'none' });
      return;
    }
    let user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    let newTeam = {
      id: Date.now(),
      avatar: "/assets/avatar/avatar1.png",
      nickname: anonymous ? "神秘玩家" : (user.nickName || "玩家"),
      school_id: user.school_id,
      game,
      gameKey: gameKey || "",
      level,
      desc,
      time: Date.now(),
      contact,
      anonymous,
      expireAt: Date.now() + 24 * 60 * 60 * 1000 // 24小时有效
    };
    let all = wx.getStorageSync('gameTeams') || [];
    all.unshift(newTeam);
    wx.setStorageSync('gameTeams', all);
    this.setData({ showPopup: false }, this.loadTeams);
    wx.showToast({ title: '发布成功', icon: 'success' });
  }
});