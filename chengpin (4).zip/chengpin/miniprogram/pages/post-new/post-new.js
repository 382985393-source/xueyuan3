const util = require('../../utils/util.js');

Page({
  data: {
    content: '',
    anonymous: true,
    tagList: [
      { name: "八卦", emoji: "🤫" },
      { name: "槽点", emoji: "😒" },
      { name: "趣事", emoji: "😂" },
      { name: "热梗", emoji: "🔥" },
      { name: "爆料", emoji: "🕵️" },
      { name: "日常", emoji: "📝" },
      { name: "寻人", emoji: "👤" },
      { name: "找物", emoji: "🔍" },
      { name: "问路", emoji: "🧭" },
      { name: "求经验", emoji: "📚" },
      { name: "解答", emoji: "💡" },
      { name: "其他", emoji: "❓" }
    ],
    selectedTags: [],
    images: [],
    uploading: false,
    board: 'gossip'
  },

  onLoad(options) {
    if (options && options.board) {
      this.setData({ board: options.board });
    }
  },

  onContentInput(e) { this.setData({ content: e.detail.value }); },
  onAnonymousChange(e) { this.setData({ anonymous: e.detail.value }); },

  onSelectTag(e) {
    const name = e.currentTarget.dataset.name;
    let selected = this.data.selectedTags;
    if (selected.indexOf(name) !== -1) {
      selected = selected.filter(t => t !== name);
    } else {
      if (selected.length >= 3) {
        wx.showToast({ title: '最多选3个标签', icon: 'none' });
        return;
      }
      selected = selected.concat(name);
    }
    this.setData({ selectedTags: selected });
  },

  onChooseImg() {
    const that = this;
    wx.chooseImage({
      count: 9 - that.data.images.length,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        that.setData({ images: that.data.images.concat(res.tempFilePaths) });
      }
    });
  },

  onRemoveImg(e) {
    const idx = e.currentTarget.dataset.idx;
    let imgs = this.data.images.slice();
    imgs.splice(idx, 1);
    this.setData({ images: imgs });
  },

  async uploadImagesToCloud(tempFilePaths) {
    if (!tempFilePaths || !tempFilePaths.length) return [];
    const uploadPromises = tempFilePaths.map((path, idx) => {
      const ext = path.substring(path.lastIndexOf('.')) || '.jpg';
      const cloudPath = `posts/${Date.now()}_${Math.floor(Math.random()*10000)}_${idx}${ext}`;
      return wx.cloud.uploadFile({ cloudPath, filePath: path });
    });
    const results = await Promise.all(uploadPromises.map(p => p.catch(e => ({ err: true, e }))));
    const fileIDs = [];
    for (const r of results) {
      if (r && r.err) throw new Error('图片上传失败');
      if (r && r.fileID) fileIDs.push(r.fileID);
    }
    return fileIDs;
  },

  async submitPost() {
    const { content, anonymous, selectedTags, images, board } = this.data;
    if (!content.trim() && images.length === 0) {
      wx.showToast({ title: '请输入内容或上传图片', icon: 'none' });
      return;
    }
    if (selectedTags.length === 0) {
      wx.showToast({ title: '请至少选择1个标签', icon: 'none' });
      return;
    }

    const user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id && !user.school && !user.school_name) {
      wx.showToast({ title: '请先选择学校', icon: 'none' });
      setTimeout(() => {
        wx.redirectTo({ url: '/pages/select-school/select-school' });
      }, 800);
      return;
    }
    const school_id = user.school_id || user.school || user.school_name || 'all';

    const nickname = user.nickName || ('瓜友' + Math.floor(1000 + Math.random() * 9000));
    const avatar = user.avatarUrl || null;

    this.setData({ uploading: true });
    wx.showLoading({ title: '发布中...' });

    try {
      let imageFileIDs = [];
      if (images && images.length) {
        imageFileIDs = await this.uploadImagesToCloud(images);
      }

      const db = wx.cloud.database();
      const now = Date.now();

      const doc = {
        title: content.trim().slice(0, 60),
        content: content.trim(),
        status: 'normal',
        school_id: school_id,
        board: board || 'gossip',            // <- 关键：确保写入 board 字段
        author_id: anonymous ? null : (user.openid || 'user'),
        author_nick: anonymous ? '匿名' : nickname,
        author_avatar: anonymous ? null : avatar,
        tags: selectedTags,
        images: imageFileIDs,
        created_at: now,
        published_at: now,
        fingerprint: `${school_id}::userpost::${now}::${Math.random().toString(36).slice(2,8)}`,
        meta: { source: 'miniapp_post_new' }
      };

      const res = await db.collection('posts').add({ data: doc });

      if (res && res._id) {
        wx.showToast({ title: '发布成功', icon: 'success' });
        setTimeout(() => { wx.navigateBack(); }, 700);
      } else {
        throw new Error('写入数据库失败');
      }
    } catch (err) {
      console.error('submitPost error', err);
      wx.showToast({ title: err && err.message ? err.message : '发布失败', icon: 'none' });
    } finally {
      this.setData({ uploading: false });
      wx.hideLoading();
    }
  }
});