Page({
  data: {
    typeOptions: ["跑腿", "代购", "其它"],
    type: "跑腿",
    title: "",
    desc: "",
    reward: "",
    contact: "",
    images: [],
    location: "",
    locationObj: null,
    time: "",
    submitting: false,
    errors: {},
    school: {}
  },
  onLoad() {
    let user = wx.getStorageSync('userInfo') || {};
    let school_id = user.school_id;
    this.setData({ school: school_id });
  },
  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [field]: e.detail.value });
    this.checkField(field);
  },
  checkField(field) {
    const { title, desc, reward } = this.data;
    let errors = this.data.errors || {};
    switch(field) {
      case "title": errors.title = !title.trim(); break;
      case "desc": errors.desc = !desc.trim(); break;
      case "reward": errors.reward = (!reward.trim() || isNaN(Number(reward)) || Number(reward) <= 0); break;
    }
    this.setData({ errors });
  },
  chooseType(e) {
    this.setData({ type: this.data.typeOptions[e.detail.value] });
  },
  chooseImages() {
    const remain = 6 - this.data.images.length;
    wx.chooseMedia({
      count: remain,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newImgs = res.tempFiles.map(f => f.tempFilePath);
        this.setData({ images: this.data.images.concat(newImgs).slice(0, 6) });
      }
    });
  },
  previewImage(e) {
    wx.previewImage({
      urls: this.data.images,
      current: this.data.images[e.currentTarget.dataset.idx]
    });
  },
  removeImage(e) {
    const idx = e.currentTarget.dataset.idx;
    let imgs = this.data.images.slice();
    imgs.splice(idx, 1);
    this.setData({ images: imgs });
  },
  chooseLocation() {
    wx.chooseLocation({
      success: res => {
        this.setData({
          location: res.address + (res.name ? ("（" + res.name + "）") : ""),
          locationObj: res
        });
      },
      fail: () => { wx.showToast({ title: '未选择位置', icon: 'none' }); }
    });
  },
  chooseTime(e) {
    this.setData({ time: e.detail.value });
  },
  submit() {
    const { type, title, desc, reward, contact, location, time, images, school } = this.data;
    let errors = {};
    if (!title.trim()) errors.title = true;
    if (!desc.trim()) errors.desc = true;
    if (!reward.trim() || isNaN(Number(reward)) || Number(reward) <= 0) errors.reward = true;
    this.setData({ errors });
    if (Object.values(errors).some(Boolean)) {
      wx.showToast({ title: '请完善所有必填项', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    let tasks = wx.getStorageSync('tasks') || [];
    const userInfo = wx.getStorageSync('userInfo') || {};
    tasks.unshift({
      id: Date.now(),
      type, title, desc,
      reward: Number(reward),
      contact, location, time,
      poster: userInfo.nickName || '匿名',
      status: "待接单",
      images,
      receiver: "",
      createTime: Date.now(),
      school_id: school
    });
    wx.setStorageSync('tasks', tasks);
    this.setData({ submitting: false });
    wx.showToast({ title: '发布成功', icon: 'success' });
    setTimeout(() => { wx.navigateBack(); }, 1000);
  }
});