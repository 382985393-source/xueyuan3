const util = require('../../utils/util.js');
const SCHOOL_LIST = [
  { id: 1, name: '清华大学', logo: '/assets/schools/tsinghua.png' },
  { id: 2, name: '北京大学', logo: '/assets/schools/pku.png' },
  { id: 3, name: '复旦大学', logo: '/assets/schools/fudan.png' }
];

Page({
  data: {
    confessList: [],
    schoolName: ''
  },
  onLoad() {
    this.loadConfessList();
  },
  onShow() {
    this.loadConfessList();
  },
  loadConfessList() {
    const user = wx.getStorageSync('userInfo') || {};
    const school_id = user.school_id;
    let list = wx.getStorageSync('confessList') || [];
    let filtered = list.filter(item => item.school_id === school_id);
    filtered = filtered.map(item => ({
      ...item,
      displayTime: util.formatTime(item.createTime)
    }));
    filtered.sort((a, b) => b.createTime - a.createTime);
    let schoolObj = SCHOOL_LIST.find(s => s.id === school_id) || {};
    this.setData({ confessList: filtered, schoolName: schoolObj.name || '' });
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/confess-detail/confess-detail?id=${id}` });
  },
  goPublish() {
    wx.navigateTo({ url: '/pages/confess-publish/confess-publish' });
  }
});