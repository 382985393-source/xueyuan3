Page({
  data: {
    inviteCount: 3,             // 已邀请人数
    rewardAmount: 32.50,        // 已获得奖励
    myInviteCode: "XY12345",    // 我的邀请码
    qrcode: "/assets/qrcode/promo.png"
  },

  onShareAppMessage() {
    return {
      title: '校园推广赚钱，现在注册有奖励！',
      path: '/pages/promo/promo?invite=' + this.data.myInviteCode
    }
  },

  copyCode() {
    wx.setClipboardData({
      data: this.data.myInviteCode,
      success: () => {
        wx.showToast({ title: '邀请码已复制', icon: 'success' });
      }
    });
  }
});