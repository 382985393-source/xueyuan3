Page({
  data: {
    userInfo: {},
    school: {},
    features: [
      {
        text: "我的帖子",
        emoji: "📝",
        bg: "linear-gradient(120deg,#aee1ff,#ffe7c5)",
        url: "/pages/my-posts/my-posts",
        desc: "管理发布的内容"
      },
      {
        text: "我的订单",
        emoji: "📦",
        bg: "linear-gradient(120deg,#ffe7c5,#aee1ff)",
        url: "/pages/my-orders/my-orders",
        desc: "任务/购物订单"
      },
      {
        text: "我的收藏",
        emoji: "⭐",
        bg: "linear-gradient(120deg,#ffc1e3,#a1f7d7)",
        url: "/pages/my-fav/my-fav",
        desc: "收藏的帖子/商品"
      },
      {
        text: "我的钱包",
        emoji: "💰",
        bg: "linear-gradient(120deg,#d1e7ff,#fdf6b7)",
        url: "/pages/my-wallet/my-wallet",
        desc: "余额、积分明细"
      },
      {
        text: "消息中心",
        emoji: "💬",
        bg: "linear-gradient(120deg,#fdf6b7,#aee1ff)",
        url: "/pages/message/message",
        desc: "系统通知、互动消息"
      },
      {
        text: "个人资料",
        emoji: "🧑‍💻",
        bg: "linear-gradient(120deg,#a1f7d7,#ffc1e3)",
        url: "/pages/profile/profile",
        desc: "修改昵称、头像等"
      },
      {
        text: "设置",
        emoji: "⚙️",
        bg: "linear-gradient(120deg,#ffe7c5,#c0f7ff)",
        url: "/pages/settings/settings",
        desc: "隐私、安全、偏好"
      },
      {
        text: "意见反馈",
        emoji: "🗣️",
        bg: "linear-gradient(120deg,#f3b2ff,#ffe7c5)",
        url: "/pages/feedback/feedback",
        desc: "提交建议或问题"
      },
      {
        text: "关于我们",
        emoji: "📖",
        bg: "linear-gradient(120deg,#eaf7ff,#ffe7c5)",
        url: "/pages/about/about",
        desc: "了解平台、开发者"
      }
    ]
  },
  onLoad() {
    let userInfo = wx.getStorageSync('userInfo') || {};
    let schoolList = require('../../utils/schools.js');
    let school = schoolList.find(s=>s.id==userInfo.school_id) || {};
    this.setData({ userInfo, school });
  },
  onShow() {
    this.onLoad();
  },
  goFeature(e) {
    const url = e.currentTarget.dataset.url;
    if (url) wx.navigateTo({ url });
  },
  changeAvatar() {
    wx.getUserProfile({
      desc: '用于完善个人资料',
      success: res => {
        const { avatarUrl, nickName } = res.userInfo;
        let userInfo = wx.getStorageSync('userInfo') || {};
        userInfo.avatarUrl = avatarUrl;
        userInfo.nickName = nickName;
        wx.setStorageSync('userInfo', userInfo);
        this.setData({ userInfo });
      },
      fail() {
        wx.showToast({ title: '授权失败', icon: 'none' });
      }
    });
  }
});