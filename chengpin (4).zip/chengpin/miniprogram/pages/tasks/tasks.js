Page({
  data: {
    tab: "all", // all, doing, done
    typeTab: "all", // all, 跑腿, 代购, 其它
    typeTabs: [
      { key: "all", name: "全部类型" },
      { key: "跑腿", name: "跑腿" },
      { key: "代购", name: "代购" },
      { key: "其它", name: "其它" }
    ],
    sort: "time", // time, reward
    sortOptions: [
      { key: "time", name: "最新任务" },
      { key: "reward", name: "赏金最高" }
    ],
    tasks: []
  },
  onShow() {
    let tasks = wx.getStorageSync('tasks') || [];
    // 默认按时间倒序
    tasks = this.sortTasks(tasks, this.data.sort);
    this.setData({ tasks });
  },
  switchTab(e) {
    this.setData({ tab: e.currentTarget.dataset.tab });
  },
  switchTypeTab(e) {
    this.setData({ typeTab: e.currentTarget.dataset.type });
  },
  switchSort(e) {
    const sort = e.currentTarget.dataset.sort;
    let tasks = wx.getStorageSync('tasks') || [];
    tasks = this.sortTasks(tasks, sort);
    this.setData({ sort, tasks });
  },
  sortTasks(tasks, sort) {
    let newTasks = [...tasks];
    if (sort === "time") {
      newTasks.sort((a, b) => b.createTime - a.createTime);
    } else if (sort === "reward") {
      newTasks.sort((a, b) => b.reward - a.reward);
    }
    return newTasks;
  },
  goNew() {
    wx.navigateTo({ url: "/pages/tasks-new/tasks-new" });
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/tasks-detail/tasks-detail?id=${id}` });
  }
});