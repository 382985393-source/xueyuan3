Page({
  data: {
    name: '',
    studentId: '',
    idPhoto: '',
    submitting: false,
    hasAuth: false // 模拟认证成功
  },
  onLoad() {
    // 真实场景下可从云端获取认证状态
    const userInfo = wx.getStorageSync('userInfo') || {};
    this.setData({ hasAuth: !!userInfo.isAuth });
  },
  onInput(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({ [field]: e.detail.value });
  },
  choosePhoto() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({ idPhoto: res.tempFiles[0].tempFilePath });
      }
    });
  },
  submitAuth() {
    const { name, studentId, idPhoto } = this.data;
    if (!name.trim() || !studentId.trim() || !idPhoto) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
      return;
    }
    this.setData({ submitting: true });
    setTimeout(() => {
      // 模拟认证成功
      let userInfo = wx.getStorageSync('userInfo') || {};
      userInfo.isAuth = true;
      wx.setStorageSync('userInfo', userInfo);
      this.setData({ submitting: false, hasAuth: true });
      wx.showToast({ title: '认证成功', icon: 'success' });
      setTimeout(() => { wx.navigateBack(); }, 1200);
    }, 1300);
  }
});