const util = require('../../utils/util.js');

const BOARD_MAP = {
  gossip: {
    storageKey: "gossipList",
    icon: "/assets/boards/gossip.svg",
    title: "吃瓜吐槽",
    publishText: "+ 我要吐槽/爆料",
    empty: "暂无瓜，快来第一个爆料！"
  },
  help: {
    storageKey: "helpList",
    icon: "/assets/boards/help.svg",
    title: "打听求助",
    publishText: "+ 我要提问/求助",
    empty: "暂无求助，快来发布你的问题！"
  }
};

const db = wx.cloud.database();
const _ = db.command;

Page({
  data: {
    postList: [],
    board: "gossip",
    boardConfig: BOARD_MAP.gossip,
    loading: false
  },

  onLoad(options) {
    const board = options && options.board ? options.board : "gossip";
    this.setData({
      board,
      boardConfig: BOARD_MAP[board] || BOARD_MAP.gossip
    });
    this.loadPostList();
  },

  onShow() {
    this.loadPostList();
  },

  // 更稳健的加载：以 school_id 值做 IN 查询（兼容多种 school_id 存储格式）
  // 然后在客户端根据 board 做容错过滤（如果帖子没有 board 字段也显示）
  async loadPostList() {
    this.setData({ loading: true });
    wx.showNavigationBarLoading && wx.showNavigationBarLoading();

    try {
      const user = wx.getStorageSync('userInfo') || {};

      // 构造可能的 school_id 候选（字符串/数字/学校名 等）
      const possible = new Set();
      if (user.school_id !== undefined && user.school_id !== null) {
        possible.add(String(user.school_id));
        possible.add(user.school_id);
      }
      if (user.school_name) possible.add(user.school_name);
      if (user.school) possible.add(user.school);
      if (user.schoolName) possible.add(user.schoolName);
      // 全校的候选
      possible.add('all');

      const candidates = Array.from(possible).filter(v => v !== '' && v !== undefined && v !== null);

      // 防护：如果没有任何候选，则使用空字符串以避免查询语法错误
      if (!candidates.length) candidates.push('');

      // 查询：按 school_id in candidates，status normal
      const res = await db.collection('posts')
        .where({ status: 'normal', school_id: _.in(candidates) })
        .orderBy('published_at', 'desc')
        .limit(200)
        .get();

      let list = (res && res.data) || [];

      // 如果页面指定了 board（例如 gossip/help），在客户端保持那些没有 board 字段的帖子也显示
      const board = this.data.board;
      if (board) {
        list = list.filter(item => {
          // 保留：帖子没有 board 字段（旧数据 / 自动生成可能没写 board）
          if (item.board === undefined || item.board === null || item.board === '') return true;
          // 或者 board 匹配
          return item.board === board;
        });
      }

      // 格式化时间
      const formatted = list.map(item => ({
        ...item,
        displayTime: (item.published_at || item.created_at) ? util.formatTime(item.published_at || item.created_at) : ''
      }));

      this.setData({ postList: formatted });
    } catch (err) {
      console.error('loadPostList error', err);
      wx.showToast && wx.showToast({ title: '加载帖子失败', icon: 'none' });

      // 回退：本地缓存（兼容旧版离线）
      try {
        const { boardConfig } = this.data;
        let list = wx.getStorageSync(boardConfig.storageKey) || [];
        const user = wx.getStorageSync('userInfo') || {};
        const school_id_local = user.school_id || 1;
        let filtered = list.filter(item => item.school_id === school_id_local);
        filtered = filtered.map(item => ({
          ...item,
          displayTime: util.formatTime(item.createTime)
        }));
        filtered.sort((a, b) => b.createTime - a.createTime);
        this.setData({ postList: filtered });
      } catch (e) {
        // ignore
      }
    } finally {
      this.setData({ loading: false });
      wx.hideNavigationBarLoading && wx.hideNavigationBarLoading();
    }
  },

  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/post-detail/post-detail?id=${id}&board=${this.data.board}` });
  },

  goPublish() {
    wx.navigateTo({ url: `/pages/post-new/post-new?board=${this.data.board}` });
  }
});