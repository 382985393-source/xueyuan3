Page({
  data: {
    task: null,
    userInfo: {},
    canAccept: false,
    canFinish: false
  },
  onLoad(options) {
    const { id } = options;
    let tasks = wx.getStorageSync('tasks') || [];
    const task = tasks.find(i => i.id == id);
    const userInfo = wx.getStorageSync('userInfo') || {};
    this.setData({
      task,
      userInfo,
      canAccept: task && task.status === "待接单" && userInfo.nickName !== task.poster,
      canFinish: task && task.status === "进行中" && userInfo.nickName === task.receiver
    });
  },
  previewImage(e) {
    wx.previewImage({
      urls: this.data.task.images,
      current: this.data.task.images[e.currentTarget.dataset.idx]
    });
  },
  accept() {
    let tasks = wx.getStorageSync('tasks') || [];
    let idx = tasks.findIndex(i => i.id == this.data.task.id);
    tasks[idx].status = "进行中";
    tasks[idx].receiver = this.data.userInfo.nickName;
    wx.setStorageSync('tasks', tasks);
    wx.showToast({ title: "接单成功", icon: "success" });
    setTimeout(() => { wx.navigateBack(); }, 1000);
  },
  finish() {
    let tasks = wx.getStorageSync('tasks') || [];
    let idx = tasks.findIndex(i => i.id == this.data.task.id);
    tasks[idx].status = "已完成";
    tasks[idx].finishTime = Date.now();
    wx.setStorageSync('tasks', tasks);

    // 奖励积分给接单人
    let userInfo = wx.getStorageSync('userInfo') || {};
    userInfo.points = (userInfo.points || 0) + tasks[idx].reward;
    wx.setStorageSync('userInfo', userInfo);

    wx.showToast({ title: "任务完成，积分+1", icon: "success" });
    setTimeout(() => { wx.navigateBack(); }, 1000);
  }
});