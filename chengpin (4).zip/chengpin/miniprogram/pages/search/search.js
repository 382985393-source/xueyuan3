const api = require('../../utils/api');
const time = require('../../utils/time');

Page({
  data: {
    results: []
  },
  doSearch(e) {
    const keyword = e.detail.value.keyword;
    if (!keyword) return wx.showToast({ title: '请输入关键词', icon: 'none' });
    api.call('search', { keyword, page: 1, pageSize: 10 }).then(res => {
      if (res.ok) {
        this.setData({ results: res.data.map(item => ({ ...item, formattedTime: time.formatTime(item.created_at) })) });
      } else {
        wx.showToast({ title: res.msg || '搜索失败', icon: 'none' });
      }
    });
  }
});