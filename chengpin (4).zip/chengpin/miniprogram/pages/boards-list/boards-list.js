const boardsUtil = require('../../utils/boards');

Page({
  data: { boards: [] },

  onLoad() {
    this.setData({ boards: boardsUtil.getAllBoards() });
  },

  openBoard(e) {
    const url = e.currentTarget.dataset.url;
    if (!url) return wx.showToast({ title: '未配置页面', icon: 'none' });

    const tabPages = [
      '/pages/home/home',
      '/pages/market/market',
      '/pages/points/points',
      '/pages/personal/personal'
    ];

    if (tabPages.includes(url)) {
      wx.switchTab({ url });
    } else {
      wx.navigateTo({ url });
    }
  }
});