const util = require('../../utils/util.js');
Page({
  data: {
    school: {},
    schools: [],
    topCategories: [
      { name: "吃瓜吐槽", emoji: "🍉", url: "/pages/post-list/post-list" },
      { name: "传纸条·交友", emoji: "📨", url: "/pages/bottle/bottle" },
      { name: "告白墙", emoji: "💬", url: "/pages/confess/confess" },
      { name: "推广赚钱", emoji: "💰", url: "/pages/promo/promo" }
    ],
    allFeatures: [
      { name: "任务大厅", emoji: "📝", url: "/pages/tasks/tasks", latest: "帮打印资料，30积分/1人" },
      { name: "游戏交友", emoji: "🎮", url: "/pages/game-social/game-social", latest: "王者组队5人已报名" },
      { name: "闲置市场", emoji: "🛒", url: "/pages/idle/idle", latest: "华为耳机低价转让" },
      { name: "失物招领", emoji: "🔑", url: "/pages/lostfound/lostfound", latest: "图书馆捡到一卡通" },
      { name: "兼职招聘", emoji: "💼", url: "/pages/post-list/post-list?board=job", latest: "食堂兼职招募中" }
    ]
  },
  onLoad() {
    const SCHOOL_LIST = require('../../utils/schools.js');
    this.setData({ schools: SCHOOL_LIST });
    let user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    let school = SCHOOL_LIST.find(s => s.id == user.school_id) || {};
    this.setData({ school });
  },
  onShow() {
    let user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    const SCHOOL_LIST = this.data.schools.length ? this.data.schools : require('../../utils/schools.js');
    let school = SCHOOL_LIST.find(s => s.id == user.school_id) || {};
    this.setData({ school });
  },
  onSchoolChange(e) {
    const school_id = e.detail.school_id;
    const school_name = e.detail.school_name;
    let school = this.data.schools.find(s => s.id == school_id) || {};
    this.setData({ school });
    let user = wx.getStorageSync('userInfo') || {};
    user.school_id = school_id;
    user.school_name = school_name || school.name;
    wx.setStorageSync('userInfo', user);
    this.onShow();
  },
  goCategory(e) {
    const url = e.currentTarget.dataset.url;
    if (url) {
      if (
        url === "/pages/tasks/tasks" ||
        url === "/pages/market/market" ||
        url === "/pages/personal/personal" ||
        url === "/pages/home/home"
      ) {
        wx.switchTab({ url });
      } else {
        wx.navigateTo({ url });
      }
    }
  }
});