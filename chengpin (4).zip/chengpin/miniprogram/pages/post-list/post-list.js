const util = require('../../utils/util.js');

const BOARD_MAP = {
  gossip: {
    storageKey: "gossipList",
    icon: "/assets/boards/gossip.svg",
    title: "吃瓜吐槽",
    publishText: "+ 我要吐槽/爆料",
    empty: "暂无瓜，快来第一个爆料！"
  },
  help: {
    storageKey: "helpList",
    icon: "/assets/boards/help.svg",
    title: "打听求助",
    publishText: "+ 我要提问/求助",
    empty: "暂无求助，快来发布你的问题！"
  }
};

const db = wx.cloud.database();
const _ = db.command;

Page({
  data: {
    postList: [],
    board: "gossip",
    boardConfig: BOARD_MAP.gossip,
    loading: false
  },

  onLoad(options) {
    const board = options && options.board ? options.board : "gossip";
    this.setData({
      board,
      boardConfig: BOARD_MAP[board] || BOARD_MAP.gossip
    });
    this.loadPostList();
    this.startRealtime(); // 启动实时监听或轮询
  },

  onShow() {
    // 仍保留 onShow 的加载策略以保证页面切换时刷新
    this.loadPostList();
  },

  onUnload() {
    this.stopRealtime();
  },

  /* --------------------
     主列表拉取逻辑（保持原有行为）
     -------------------- */
  async loadPostList() {
    this.setData({ loading: true });
    wx.showNavigationBarLoading && wx.showNavigationBarLoading();

    try {
      const user = wx.getStorageSync('userInfo') || {};

      // 构造可能的 school 标识集（兼容数字/字符串/名称）
      const possible = new Set();
      if (user.school_id !== undefined && user.school_id !== null) {
        possible.add(String(user.school_id));
        possible.add(user.school_id);
      }
      if (user.school_name) possible.add(user.school_name);
      if (user.school) possible.add(user.school);
      if (user.schoolName) possible.add(user.schoolName);
      possible.add('all');

      const candidates = Array.from(possible).filter(v => v !== '' && v !== undefined && v !== null);
      if (!candidates.length) candidates.push('');

      // 查询 posts：按 school_id IN candidates 且 status normal
      const res = await db.collection('posts')
        .where({ status: 'normal', school_id: _.in(candidates) })
        .orderBy('published_at', 'desc')
        .limit(200)
        .get();

      let list = (res && res.data) || [];

      // 如果当前板块有值，保留没有 board 字段的帖子（兼容旧数据），同时筛选匹配 board 的帖子
      const board = this.data.board;
      if (board) {
        list = list.filter(item => {
          if (item.board === undefined || item.board === null || item.board === '') return true;
          return item.board === board;
        });
      }

      const formatted = list.map(item => ({
        ...item,
        displayTime: (item.published_at || item.created_at) ? util.formatTime(item.published_at || item.created_at) : ''
      }));

      this.setData({ postList: formatted });
    } catch (err) {
      console.error('loadPostList error', err);
      wx.showToast && wx.showToast({ title: '加载帖子失败', icon: 'none' });

      // 回退到本地缓存（兼容旧逻辑）
      try {
        const { boardConfig } = this.data;
        let list = wx.getStorageSync(boardConfig.storageKey) || [];
        const user = wx.getStorageSync('userInfo') || {};
        const school_id_local = user.school_id || 1;
        let filtered = list.filter(item => item.school_id === school_id_local);
        filtered = filtered.map(item => ({
          ...item,
          displayTime: util.formatTime(item.createTime)
        }));
        filtered.sort((a, b) => b.createTime - a.createTime);
        this.setData({ postList: filtered });
      } catch (e) {
        // ignore fallback errors
      }
    } finally {
      this.setData({ loading: false });
      wx.hideNavigationBarLoading && wx.hideNavigationBarLoading();
    }
  },

  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/post-detail/post-detail?id=${id}&board=${this.data.board}` });
  },

  goPublish() {
    wx.navigateTo({ url: `/pages/post-new/post-new?board=${this.data.board}` });
  },

  /* --------------------
     实时监听 / 轮询 逻辑
     -------------------- */

  startRealtime() {
    // 已经启动则跳过
    if (this._realtimeStarted) return;
    this._realtimeStarted = true;

    // guard：确保 cloud DB 支持 watch
    try {
      if (db && db.collection && typeof db.collection('posts').watch === 'function') {
        // 建立一个 watch（尽量加基础筛选 status:'normal'，再在 onChange 里做更细筛选）
        const that = this;

        // 为了根据当前用户的 school 过滤，我们先读取本地 userInfo 构造 candidates
        const user = wx.getStorageSync('userInfo') || {};
        const possible = new Set();
        if (user.school_id !== undefined && user.school_id !== null) {
          possible.add(String(user.school_id));
          possible.add(user.school_id);
        }
        if (user.school_name) possible.add(user.school_name);
        if (user.school) possible.add(user.school);
        if (user.schoolName) possible.add(user.schoolName);
        possible.add('all');
        const candidates = Array.from(possible).filter(v => v !== '' && v !== undefined && v !== null);

        this._watcher = db.collection('posts').where({ status: 'normal' }).watch({
          onChange: function(snapshot) {
            // snapshot.docs 包含变更后的文档快照（可能包含很多条）
            if (!snapshot || !snapshot.docs) return;
            const board = that.data.board;

            // 过滤：按 school_id 与 board 再格式化
            const filtered = (snapshot.docs || []).filter(d => {
              const sid = d.school_id;
              const sidStr = sid !== undefined && sid !== null ? String(sid) : '';
              const matchesSchool = candidates.length ? candidates.some(c => String(c) === sidStr) : true;
              const matchesBoard = !board || d.board === undefined || d.board === null || d.board === '' ? true : d.board === board;
              return matchesSchool && matchesBoard && d.status === 'normal';
            }).map(item => ({
              ...item,
              displayTime: (item.published_at || item.created_at) ? util.formatTime(item.published_at || item.created_at) : ''
            }));

            // 将最新结果按时间排序并替换页面列表（简单直接）
            filtered.sort((a, b) => (b.published_at || b.created_at) - (a.published_at || a.created_at));
            that.setData({ postList: filtered });
          },
          onError: function(err) {
            console.error('posts watch error', err);
            // 如果 watch 出错（权限/环境/版本问题），降级到轮询
            that._watcher = null;
            that._startPollFallback();
          }
        });
        console.log('posts watch started');
      } else {
        // watch 不可用，使用轮询
        this._startPollFallback();
      }
    } catch (e) {
      console.error('startRealtime error', e);
      this._startPollFallback();
    }
  },

  _startPollFallback() {
    // 每 30 秒轮询一次（可根据需要调整）
    if (this._pollTimer) return;
    this._pollTimer = setInterval(() => {
      this.loadPostList();
    }, 30000);
    console.log('fallback poll started (every 30s)');
  },

  stopRealtime() {
    // 关闭 watcher
    try {
      if (this._watcher && typeof this._watcher.close === 'function') {
        this._watcher.close();
        this._watcher = null;
        console.log('posts watch closed');
      }
    } catch (e) {
      console.error('stopRealtime watcher close error', e);
    }

    // 清除轮询
    if (this._pollTimer) {
      clearInterval(this._pollTimer);
      this._pollTimer = null;
      console.log('fallback poll stopped');
    }

    this._realtimeStarted = false;
  }
});