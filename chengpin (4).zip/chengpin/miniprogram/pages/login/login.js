Page({
  // ...
  getUserProfile() {
    wx.getUserProfile({
      desc: '用于完善会员资料',
      success: (res) => {
        // 保存头像和昵称
        wx.setStorageSync('userInfo', res.userInfo);
        this.setData({ hasUserInfo: true, userInfo: res.userInfo });
        wx.switchTab({ url: '/pages/home/home' });
      },
      fail: () => {
        wx.showToast({ title: '未授权无法使用', icon: 'none' });
      }
    });
  },
  // ...
});