Page({
  data: {
    postList: []
  },
  onShow() {
    this.loadPosts();
  },
  loadPosts() {
    // 示例数据，实际请用后端API或本地缓存
    let posts = wx.getStorageSync('myPosts') || [];
    // 给每个卡片加渐变色
    const bgArr = [
      "linear-gradient(120deg,#aee1ff,#ffe7c5)",
      "linear-gradient(120deg,#ffc1e3,#a1f7d7)",
      "linear-gradient(120deg,#d1e7ff,#fdf6b7)"
    ];
    posts.forEach((item, idx) => {
      item.bg = bgArr[idx % bgArr.length];
    });
    this.setData({ postList: posts });
  },
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/post-detail/post-detail?id=${id}` });
  },
  editPost(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({ url: `/pages/post-new/post-new?id=${id}` });
  },
  delPost(e) {
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title: "确认删除",
      content: "删除后不可恢复，确定要删除吗？",
      success: res => {
        if (res.confirm) {
          let posts = wx.getStorageSync('myPosts') || [];
          posts = posts.filter(item => item.id !== id);
          wx.setStorageSync('myPosts', posts);
          this.loadPosts();
          wx.showToast({ title: '已删除', icon: 'success' });
        }
      }
    });
  }
});