const api = require('../../utils/api');

Page({
  data: { user: {} },

  onLoad() {
    this.loadUser();
  },

  async loadUser() {
    const res = await api.call('user_info', {});
    if (res.ok) {
      this.setData({ user: res.data.user || {} });
    } else {
      console.warn('user_info err', res.msg);
    }
  },

  goRecords() {
    wx.navigateTo({ url: '/pages/points-records/points-records' });
  },

  goMarket() {
    wx.switchTab({ url: '/pages/market/market' });
  }
});