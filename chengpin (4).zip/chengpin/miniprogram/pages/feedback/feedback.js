Page({
  data: {
    content: ""
  },
  onInput(e) {
    this.setData({ content: e.detail.value });
  },
  submit() {
    if (!this.data.content.trim()) {
      wx.showToast({ title: '请输入反馈内容', icon: 'none' });
      return;
    }
    wx.showToast({ title: '提交成功', icon: 'success' });
    this.setData({ content: "" });
    // 这里可以上传到服务器
  }
});