Page({
  data: {
    favGroups: [
      {
        name: "帖子",
        type: 'post',
        emoji: "📝",
        list: [
          { id: 1, title: "精彩吐槽1", bg: "linear-gradient(90deg,#eaf7ff,#ffe7c5)" },
          { id: 2, title: "校园活动", bg: "linear-gradient(90deg,#ffc1e3,#a1f7d7)" }
        ]
      },
      {
        name: "商品",
        type: 'goods',
        emoji: "🛒",
        list: [
          { id: 10, title: "二手耳机", bg: "linear-gradient(90deg,#d1e7ff,#fdf6b7)" }
        ]
      }
    ]
  },
  goDetail(e) {
    wx.showToast({title:'进入详情（待开发）',icon:'none'});
  },
  cancelFav(e) {
    const type = e.currentTarget.dataset.type;
    const id = e.currentTarget.dataset.id;
    let favGroups = this.data.favGroups.map(group => {
      if (group.type === type) {
        group.list = group.list.filter(item => item.id !== id);
      }
      return group;
    });
    this.setData({ favGroups });
    wx.showToast({ title: '已取消收藏', icon: 'success' });
  }
});