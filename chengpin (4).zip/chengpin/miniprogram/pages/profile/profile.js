Page({
  data: {
    nickname: "",
    school: "",
    phone: ""
  },
  onLoad() {
    // 可从本地或云端获取用户资料填充
    const userInfo = wx.getStorageSync('userInfo') || {};
    this.setData({
      nickname: userInfo.nickName || "",
      school: userInfo.school || "",
      phone: userInfo.phone || ""
    });
  },
  onInput(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({ [field]: e.detail.value });
  },
  save() {
    let userInfo = wx.getStorageSync('userInfo') || {};
    userInfo.nickName = this.data.nickname;
    userInfo.school = this.data.school;
    userInfo.phone = this.data.phone;
    wx.setStorageSync('userInfo', userInfo);
    wx.showToast({ title: '资料已保存', icon: 'success' });
  }
});