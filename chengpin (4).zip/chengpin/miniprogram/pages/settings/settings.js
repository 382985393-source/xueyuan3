Page({
  goProfile() {
    wx.navigateTo({ url: '/pages/profile/profile' });
  },
  goFeedback() {
    wx.navigateTo({ url: '/pages/feedback/feedback' });
  },
  goAbout() {
    wx.navigateTo({ url: '/pages/about/about' });
  },
  logout() {
    wx.showToast({ title: '已退出登录', icon: 'success' });
    // 这里可以加上清除token/跳转登录等逻辑
  }
});