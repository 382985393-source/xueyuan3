const boardsUtil = require('../../utils/boards');
Page({
  data: { items: [] },
  onLoad() {
    const board = boardsUtil.findById('gossip') || {};
    const items = Array.from({ length: 9 }).map((_, i) => ({
      _id: 'gossip_' + i,
      title: `${board.name || '吃瓜'} 示例 ${i+1}`,
      emoji: board.emoji || '🍉',
      gradient: board.gradient || 'background: linear-gradient(135deg,#fbc2eb,#a6c1ee);'
    }));
    this.setData({ items });
  }
});