const api = require('../../utils/api');

Page({
  data: {
    items: [],
    page: 1,
    pageSize: 12,
    loading: false,
    q: ''
  },

  onLoad() {
    this.load();
  },

  onInput(e) { this.setData({ q: e.detail.value }); },

  onSearch() {
    this.setData({ items: [], page: 1 }, () => this.load());
  },

  onPublish() {
    wx.showToast({ title: '暂不支持发布（请在后台添加）', icon: 'none' });
  },

  async load() {
    if (this.data.loading) return;
    this.setData({ loading: true });
    const res = await api.call('market_list', { page: this.data.page, pageSize: this.data.pageSize, q: this.data.q });
    if (res.ok) {
      const list = res.data || [];
      if (!list.length && this.data.page === 1) {
        const placeholders = Array.from({ length: 9 }).map((_, i) => ({
          _id: 'ph_' + i,
          title: `示例商品 ${i+1}`,
          price: (i + 1) * 10,
          cover: '/assets/boards/market.svg'
        }));
        this.setData({ items: placeholders });
      } else {
        this.setData({ items: this.data.items.concat(list) });
        if (list.length >= this.data.pageSize) this.setData({ page: this.data.page + 1 });
      }
    } else {
      if (!this.data.items.length) {
        const placeholders = Array.from({ length: 9 }).map((_, i) => ({
          _id: 'ph_' + i,
          title: `示例商品 ${i+1}`,
          price: (i + 1) * 10,
          cover: '/assets/boards/market.svg'
        }));
        this.setData({ items: placeholders });
      }
      console.warn('market.load err', res.msg);
    }
    this.setData({ loading: false });
  },

  loadMore() { this.load(); },

  onBack() {
    wx.navigateBack();
  }
});