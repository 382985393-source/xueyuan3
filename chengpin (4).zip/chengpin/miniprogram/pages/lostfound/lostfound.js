Page({
  data: {
    activeType: 'lost', // 'lost' or 'found'
    itemList: [],
  },
  onShow() {
    this.filterList();
  },
  onTypeChange(e) {
    this.setData({ activeType: e.currentTarget.dataset.type }, this.filterList);
  },
  onSearchInput(e) {
    this.searchText = e.detail.value.trim();
    this.filterList();
  },
  filterList() {
    let itemList = wx.getStorageSync('lostFoundList') || [];
    itemList = itemList.filter(item => item.type === this.data.activeType);
    if (this.searchText) {
      const kw = this.searchText;
      itemList = itemList.filter(item =>
        item.title.includes(kw) ||
        item.desc.includes(kw) ||
        item.place.includes(kw) ||
        item.tags.join(',').includes(kw)
      );
    }
    itemList.sort((a, b) => b.createTime - a.createTime);
    itemList.forEach(item => {
      item.displayTime = this.formatTime(item.createTime);
    });
    this.setData({ itemList });
  },
  goPublish() {
    wx.navigateTo({ url: '/pages/lostfound/publish' });
  },
  goDetail(e) {
    wx.navigateTo({ url: `/pages/lostfound/detail?id=${e.currentTarget.dataset.id}` });
  },
  formatTime(ts) {
    const d = new Date(ts);
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
  }
});