Page({
  data: {
    tagList: ['雨伞','钥匙','钱包','卡片','衣物','数码','书籍','其它'],
    form: {
      type: 'lost', // 'lost' or 'found'
      title: '',
      desc: '',
      place: '',
      contact: '',
      tags: [],
      images: []
    }
  },
  onTypeChange(e) {
    this.setData({ 'form.type': e.currentTarget.dataset.type });
  },
  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`form.${field}`]: e.detail.value });
  },
  onTagSelect(e) {
    const tag = e.currentTarget.dataset.tag;
    let tags = this.data.form.tags.slice();
    const idx = tags.indexOf(tag);
    if (idx === -1) {
      if (tags.length < 3) tags.push(tag);
      else wx.showToast({ title: '最多选3个标签', icon: 'none' });
    } else {
      tags.splice(idx, 1);
    }
    this.setData({ 'form.tags': tags });
  },
  onChooseImg() {
    const that = this;
    wx.chooseImage({
      count: 6 - that.data.form.images.length,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success(res) {
        let imgs = that.data.form.images.concat(res.tempFilePaths);
        if (imgs.length > 6) imgs = imgs.slice(0, 6);
        that.setData({ 'form.images': imgs });
      }
    });
  },
  onRemoveImg(e) {
    const idx = e.currentTarget.dataset.idx;
    let imgs = this.data.form.images.slice();
    imgs.splice(idx, 1);
    this.setData({ 'form.images': imgs });
  },
  submit() {
    const { type, title, desc, place, contact, tags, images } = this.data.form;
    if (!title.trim() || !desc.trim() || !place.trim() || !contact.trim() || images.length === 0) {
      wx.showToast({ title: '请填写全部必填项', icon: 'none' }); return;
    }
    const user = wx.getStorageSync('userInfo') || {};
    let lostFoundList = wx.getStorageSync('lostFoundList') || [];
    lostFoundList.unshift({
      id: Date.now(),
      type,
      title: title.trim(),
      desc,
      place,
      contact,
      tags,
      images,
      anonymous: false,
      nickname: user.nickName || '用户',
      avatar: user.avatarUrl || '',
      status: 'open',
      createTime: Date.now()
    });
    wx.setStorageSync('lostFoundList', lostFoundList);
    wx.showToast({ title: '发布成功', icon: 'success' });
    const pages = getCurrentPages();
    if (pages.length > 1 && pages[pages.length-2].route.indexOf('lostfound/lostfound') !== -1) {
      pages[pages.length-2].onShow && pages[pages.length-2].onShow();
    }
    setTimeout(()=>{ wx.navigateBack(); }, 900);
  }
});