Page({
  data: {
    balance: 128.00,
    points: 2350,
    billList: [
      { id: 1, type: '收入', amount: 20, desc: '任务奖励', date: '2025-10-15 12:00' },
      { id: 2, type: '支出', amount: 15, desc: '兑换商品', date: '2025-10-14 16:18' },
      { id: 3, type: '收入', amount: 50, desc: '提现到账', date: '2025-10-13 09:23' },
      { id: 4, type: '支出', amount: 10, desc: '充值积分', date: '2025-10-10 11:00' }
    ]
  },
  toRecharge() {
    wx.showToast({ title: '充值功能开发中', icon: 'none' });
  },
  toWithdraw() {
    wx.showToast({ title: '提现功能开发中', icon: 'none' });
  }
});