Page({
  data: {
    fromUser: '',
    toUser: '',
    content: '',
    anonymous: false
  },
  onFromUserInput(e) {
    this.setData({ fromUser: e.detail.value });
  },
  onToUserInput(e) {
    this.setData({ toUser: e.detail.value });
  },
  onContentInput(e) {
    this.setData({ content: e.detail.value });
  },
  onAnonymousChange(e) {
    this.setData({ anonymous: e.detail.value });
  },
  submitPublish() {
    const { fromUser, toUser, content, anonymous } = this.data;
    if (!content.trim()) {
      wx.showToast({ title: '请输入告白内容', icon: 'none' });
      return;
    }
    const user = wx.getStorageSync('userInfo') || {};
    const school_id = user.school_id;
    let confessList = wx.getStorageSync('confessList') || [];
    confessList.unshift({
      id: Date.now(),
      fromUser: fromUser.trim() || '匿名',
      toUser: toUser.trim(),
      content: content.trim(),
      anonymous,
      createTime: Date.now(),
      likes: 0,
      comments: 0,
      school_id
    });
    wx.setStorageSync('confessList', confessList);
    wx.showToast({ title: '发布成功', icon: 'success' });
    setTimeout(() => { wx.navigateBack(); }, 800);
  }
});