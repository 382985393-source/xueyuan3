Page({
  data: {
    orderGroups: [
      {
        name: "任务订单",
        type:'task',
        emoji: "📝",
        list: [
          { id: 1, title: "帮打印资料", date: "10-15", status: "已完成", bg:"linear-gradient(90deg,#eaf7ff,#ffe7c5)", canCancel:false, canPay:false },
          { id: 2, title: "搬寝室", date: "10-14", status: "待支付", bg:"linear-gradient(90deg,#ffc1e3,#a1f7d7)", canCancel:true, canPay:true }
        ]
      },
      {
        name: "商城订单",
        type:'goods',
        emoji: "🛒",
        list: [
          { id: 10, title: "二手耳机", date: "10-13", status: "待发货", bg:"linear-gradient(90deg,#d1e7ff,#fdf6b7)", canCancel:true, canPay:false }
        ]
      }
    ]
  },
  viewOrder(e) {
    wx.showToast({title:'查看订单（待开发）',icon:'none'});
  },
  cancelOrder(e) {
    const type = e.currentTarget.dataset.type;
    const id = e.currentTarget.dataset.id;
    let orderGroups = this.data.orderGroups.map(group => {
      if (group.type === type) {
        group.list = group.list.filter(item => item.id !== id);
      }
      return group;
    });
    this.setData({ orderGroups });
    wx.showToast({ title: '已取消订单', icon: 'success' });
  },
  payOrder(e) {
    wx.showToast({title:'支付功能开发中',icon:'none'});
  }
});