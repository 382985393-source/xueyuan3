const util = require('../../utils/util.js');

Page({
  data: {
    post: {},
    comments: [],
    commentInput: ''
  },
  onLoad(options) {
    const id = Number(options.id);
    let list = wx.getStorageSync('gossipList') || [];
    let post = list.find(item => item.id === id) || {};
    post.displayTime = util.formatTime(post.createTime);
    this.setData({ post });
    this.loadComments(id);
  },
  loadComments(postId) {
    let all = wx.getStorageSync('gossipComments') || [];
    let comments = all.filter(item => item.post_id === postId)
      .map(item => ({ ...item, displayTime: util.formatTime(item.createTime) }));
    comments.sort((a, b) => a.createTime - b.createTime);
    this.setData({ comments });
  },
  onCommentInput(e) {
    this.setData({ commentInput: e.detail.value });
  },
  submitComment() {
    let content = this.data.commentInput.trim();
    if (!content) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' });
      return;
    }
    let all = wx.getStorageSync('gossipComments') || [];
    let comment = {
      id: Date.now(),
      post_id: this.data.post.id,
      user: '瓜友' + Math.floor(1000 + Math.random()*9000),
      content: content,
      createTime: Date.now()
    };
    all.push(comment);
    wx.setStorageSync('gossipComments', all);
    // 增加评论数
    let list = wx.getStorageSync('gossipList') || [];
    const idx = list.findIndex(item => item.id === this.data.post.id);
    if (idx > -1) {
      list[idx].comments = (list[idx].comments || 0) + 1;
      wx.setStorageSync('gossipList', list);
    }
    this.setData({ commentInput: '' });
    this.loadComments(this.data.post.id);
    wx.showToast({ title: '评论成功', icon: 'success' });
  },
  likePost() {
    let post = this.data.post;
    post.likes = (post.likes || 0) + 1;
    this.setData({ post });
    let list = wx.getStorageSync('gossipList') || [];
    const idx = list.findIndex(item => item.id === post.id);
    if (idx > -1) {
      list[idx].likes = post.likes;
      wx.setStorageSync('gossipList', list);
    }
  },
  eatMelon() {
    let post = this.data.post;
    post.eaters = (post.eaters || 0) + 1;
    this.setData({ post });
    let list = wx.getStorageSync('gossipList') || [];
    const idx = list.findIndex(item => item.id === post.id);
    if (idx > -1) {
      list[idx].eaters = post.eaters;
      wx.setStorageSync('gossipList', list);
    }
  },
  reportPost() {
    wx.showModal({
      title: '举报',
      content: '如发现违规、谣言、恶意内容请举报，我们会及时处理！',
      confirmText: '举报',
      success: res => {
        if (res.confirm) {
          wx.showToast({ title: '已举报', icon: 'success' });
        }
      }
    });
  }
});