const util = require('../../utils/util.js');
// 模拟活跃用户列表（实际从后端获取）
const ACTIVE_USERS = [
  { id: 1, name: "活跃用户A", avatar: "/assets/bottle/active1.png" },
  { id: 2, name: "活跃用户B", avatar: "/assets/bottle/active2.png" },
  { id: 3, name: "活跃用户C", avatar: "/assets/bottle/active3.png" },
  { id: 4, name: "活跃用户D", avatar: "/assets/bottle/active4.png" },
  { id: 5, name: "活跃用户E", avatar: "/assets/bottle/active5.png" }
];

Page({
  data: {
    tabs: [
      { key: 'all', label: '全部', color: '#2d8cf0' },
      { key: 'male', label: '男生', color: '#13c26b' },
      { key: 'female', label: '女生', color: '#ff4949' }
    ],
    activeTab: 'all',
    cards: {
      all: [
        { icon: '/assets/bottle/match.png', text: '随机匹配男生', type: 'male' },
        { icon: '/assets/bottle/match.png', text: '随机匹配女生', type: 'female' },
        { icon: '/assets/bottle/city.png', text: '同城男生', type: 'male', city: true },
        { icon: '/assets/bottle/city.png', text: '同城女生', type: 'female', city: true }
      ],
      male: [
        { icon: '/assets/bottle/match.png', text: '随机匹配男生', type: 'male' },
        { icon: '/assets/bottle/city.png', text: '同城男生', type: 'male', city: true }
      ],
      female: [
        { icon: '/assets/bottle/match.png', text: '随机匹配女生', type: 'female' },
        { icon: '/assets/bottle/city.png', text: '同城女生', type: 'female', city: true }
      ]
    },
    bottleList: [],
    showPopup: false,
    popupType: 'all',
    form: {
      contact: '',
      star: '',
      city: '',
      age: '',
      gender: '',
      text: '',
      anonymous: true,
      cover: ''
    },
    starOptions: ['白羊座','金牛座','双子座','巨蟹座','狮子座','处女座','天秤座','天蝎座','射手座','摩羯座','水瓶座','双鱼座'],
    genderOptions: ['男', '女'],
    statusOptions: {
      pending: "待抽取",
      active: "已自动发送",
      received: "已被接收"
    },
    userInfo: {
      id: 1001,
      name: "我自己",
      avatar: "/assets/bottle/me.png"
    },
    school: {} // 当前学校
  },
  onLoad() {
    // 强制选择学校，未选学校跳转
    const user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    this.setData({ school_id: user.school_id, school: { id: user.school_id, name: user.school_name } });
    this.loadBottleList();
    this.autoSendTimer = setInterval(() => {
      this.checkAutoSend();
    }, 60000);
  },
  onShow() {
    // 再次校验学校
    const user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.redirectTo({ url: '/pages/select-school/select-school' });
      return;
    }
    this.setData({ school_id: user.school_id, school: { id: user.school_id, name: user.school_name } });
    this.loadBottleList();
  },
  onUnload() {
    clearInterval(this.autoSendTimer);
  },
  loadBottleList() {
    let user = wx.getStorageSync('userInfo') || {};
    let school_id = user.school_id;
    let list = wx.getStorageSync('bottleList') || [];
    // 只显示当前学校的纸条
    list = list.filter(item => item.school_id === school_id);
    // 只取当前分类
    let filtered = list.filter(item => {
      if (this.data.activeTab === 'all') return true;
      if (this.data.activeTab === 'male') return item.gender === '男' || item.type === 'male';
      if (this.data.activeTab === 'female') return item.gender === '女' || item.type === 'female';
      return true;
    });

    // 处理剩余时间与状态
    filtered = filtered.map(item => {
      let t = Number(item.time);
      if (!t || isNaN(t) || t < 1e11) t = Date.now();
      const expire = t + 3 * 24 * 60 * 60 * 1000;
      const now = Date.now();
      let left = expire - now;
      let leftDay = Math.max(0, Math.floor(left / (24 * 60 * 60 * 1000)));
      let leftHour = Math.max(0, Math.floor(left % (24 * 60 * 60 * 1000) / (60 * 60 * 1000)));
      let status = item.status || 'pending';
      if (item.receivedBy) status = 'received';
      if (!item.receivedBy && now > expire && item.status !== 'received') status = 'active';
      return {
        ...item,
        displayTime: util.formatTime(t),
        leftDay,
        leftHour,
        status
      };
    });
    // 按时间倒序排序
    filtered.sort((a, b) => b.time - a.time);
    this.setData({ bottleList: filtered });
  },
  switchTab(e) {
    this.setData({ activeTab: e.currentTarget.dataset.tab }, () => {
      this.loadBottleList();
    });
  },
  openPopup(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      showPopup: true,
      popupType: type,
      form: {
        contact: '',
        star: '',
        city: '',
        age: '',
        gender: type === 'male' ? '男' : type === 'female' ? '女' : '',
        text: '',
        anonymous: true,
        cover: ''
      }
    });
  },
  closePopup() {
    this.setData({ showPopup: false });
  },
  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`form.${field}`]: e.detail.value });
  },
  chooseStar(e) {
    this.setData({ 'form.star': this.data.starOptions[e.detail.value] });
  },
  chooseGender(e) {
    this.setData({ 'form.gender': this.data.genderOptions[e.detail.value] });
  },
  toggleAnonymous(e) {
    this.setData({ 'form.anonymous': e.detail.value });
  },
  chooseCover() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const cover = res.tempFiles[0].tempFilePath;
        this.setData({ 'form.cover': cover });
      }
    });
  },
  submitBottle() {
    const { contact, star, city, age, gender, text, anonymous, cover } = this.data.form;
    if (!cover) {
      wx.showToast({ title: '请上传封面图', icon: 'none' });
      return;
    }
    // 校验学校
    const user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.showToast({ title: '请先选择学校', icon: 'none' });
      setTimeout(() => {
        wx.redirectTo({ url: '/pages/select-school/select-school' });
      }, 800);
      return;
    }
    const school_id = user.school_id;
    const newBottle = {
      contact, star, city, age, gender, text,
      anonymous,
      cover,
      type: this.data.popupType,
      time: Date.now(),
      sender: anonymous ? null : { ...this.data.userInfo },
      status: 'pending',
      receivedBy: null,
      school_id // 绑定当前学校
    };
    let list = wx.getStorageSync('bottleList') || [];
    list.unshift(newBottle);
    wx.setStorageSync('bottleList', list);
    this.setData({ showPopup: false }, () => {
      this.loadBottleList();
    });
    wx.showToast({ title: '已提交', icon: 'success' });
  },
  checkAutoSend() {
    let list = wx.getStorageSync('bottleList') || [];
    let changed = false;
    const now = Date.now();
    list.forEach(item => {
      if (!item.receivedBy && now > item.time + 3 * 24 * 60 * 60 * 1000 && item.status !== 'active') {
        const receivers = this.getRandomActiveUsers();
        item.autoReceivers = receivers;
        item.status = 'active';
        changed = true;
      }
    });
    if (changed) {
      wx.setStorageSync('bottleList', list);
      this.loadBottleList();
    }
  },
  getRandomActiveUsers() {
    let arr = ACTIVE_USERS.slice(0);
    arr.sort(() => Math.random() - 0.5);
    const n = Math.floor(Math.random() * 3) + 3;
    return arr.slice(0, n);
  },
  // 查看纸条详情（仅展示时间和状态，不展示内容）
  viewDetail(e) {
    const idx = e.currentTarget.dataset.idx;
    const bottle = this.data.bottleList[idx];
    let detail = '';
    detail += `提交时间：${bottle.displayTime}\n`;
    detail += `状态：${this.data.statusOptions[bottle.status]||bottle.status}\n`;
    if (bottle.status === 'received' && bottle.receivedBy) {
      detail += `接收者：${bottle.receivedBy.name}`;
    } else if (bottle.status === 'active' && bottle.autoReceivers) {
      detail += "已自动发送给：";
      bottle.autoReceivers.forEach(u => {
        detail += `${u.name} `;
      });
    }
    wx.showModal({ title: '纸条详情', content: detail, showCancel: false });
  }
});