const util = require('../../utils/util.js');
const SCHOOL_LIST = [
  { id: 1, name: '清华大学', logo: '/assets/schools/tsinghua.png' },
  { id: 2, name: '北京大学', logo: '/assets/schools/pku.png' },
  { id: 3, name: '复旦大学', logo: '/assets/schools/fudan.png' }
];

Page({
  data: {
    confess: {},
    schoolName: '',
    comments: [],
    commentInput: ''
  },
  onLoad(options) {
    const id = Number(options.id);
    let confessList = wx.getStorageSync('confessList') || [];
    let confess = confessList.find(item => item.id === id) || {};
    confess.displayTime = util.formatTime(confess.createTime);
    let schoolItem = SCHOOL_LIST.find(s => s.id === confess.school_id) || {};
    this.setData({ confess, schoolName: schoolItem.name || '' });
    this.loadComments(id);
  },
  loadComments(confessId) {
    let commentList = wx.getStorageSync('confessComments') || [];
    let comments = commentList
      .filter(item => item.confess_id === confessId)
      .map(item => ({ ...item, displayTime: util.formatTime(item.createTime) }));
    comments.sort((a, b) => a.createTime - b.createTime);
    this.setData({ comments });
  },
  likeConfess() {
    let confess = this.data.confess;
    confess.likes = (confess.likes || 0) + 1;
    this.setData({ confess });
    // 同步存储
    let confessList = wx.getStorageSync('confessList') || [];
    const idx = confessList.findIndex(item => item.id === confess.id);
    if (idx > -1) {
      confessList[idx].likes = confess.likes;
      wx.setStorageSync('confessList', confessList);
    }
  },
  showCommentInput() {
    // 可选：让输入框获得焦点
  },
  onCommentInput(e) {
    this.setData({ commentInput: e.detail.value });
  },
  submitComment() {
    let content = this.data.commentInput.trim();
    if (!content) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' });
      return;
    }
    let commentList = wx.getStorageSync('confessComments') || [];
    let comment = {
      id: Date.now(),
      confess_id: this.data.confess.id,
      user: '匿名用户',
      content: content,
      createTime: Date.now()
    };
    commentList.push(comment);
    wx.setStorageSync('confessComments', commentList);
    // 增加评论数
    let confessList = wx.getStorageSync('confessList') || [];
    const idx = confessList.findIndex(item => item.id === this.data.confess.id);
    if (idx > -1) {
      confessList[idx].comments = (confessList[idx].comments || 0) + 1;
      wx.setStorageSync('confessList', confessList);
    }
    this.setData({ commentInput: '' });
    this.loadComments(this.data.confess.id);
    wx.showToast({ title: '评论成功', icon: 'success' });
  },
  reportConfess() {
    wx.showModal({
      title: '举报',
      content: '如发现违规、恶意等内容请举报，我们会及时处理！',
      confirmText: '举报',
      success: res => {
        if (res.confirm) {
          wx.showToast({ title: '已举报', icon: 'success' });
        }
      }
    });
  }
});