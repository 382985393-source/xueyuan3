const schools = require('../../utils/schools.js'); // 见下方示例

Page({
  data: {
    searchText: '',
    schools: [],
    filteredSchools: []
  },
  onLoad() {
    this.setData({
      schools,
      filteredSchools: schools
    });
  },
  onSearch(e) {
    const val = e.detail.value.trim().toLowerCase();
    const filtered = this.data.schools.filter(s =>
      s.name.toLowerCase().includes(val) || (s.pinyin && s.pinyin.includes(val))
    );
    this.setData({ searchText: val, filteredSchools: filtered });
  },
  chooseSchool(e) {
    const school_id = e.currentTarget.dataset.id;
    const school_name = e.currentTarget.dataset.name;
    let user = wx.getStorageSync('userInfo') || {};
    user.school_id = school_id;
    user.school_name = school_name;
    wx.setStorageSync('userInfo', user);
    wx.showToast({ title: '选择成功', icon: 'success' });
    setTimeout(() => {
      wx.reLaunch({ url: '/pages/home/home' });
    }, 500);
  }
});