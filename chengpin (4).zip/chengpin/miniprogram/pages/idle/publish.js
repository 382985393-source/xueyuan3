Page({
  data: {
    categoryList: ['数码','图书','美妆','家具','运动','其它'],
    tagList: ['九成新','可刀','急售','包邮','自提','无磕碰'],
    form: {
      title: '',
      desc: '',
      price: '',
      contact: '',
      category: '',
      tags: [],
      images: []
    }
  },
  onInput(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({ [`form.${field}`]: e.detail.value });
  },
  onCategoryChange(e) {
    this.setData({ 'form.category': this.data.categoryList[e.detail.value] });
  },
  onTagSelect(e) {
    const tag = e.currentTarget.dataset.tag;
    let tags = this.data.form.tags.slice();
    const idx = tags.indexOf(tag);
    if (idx === -1) {
      if (tags.length < 3) tags.push(tag);
      else wx.showToast({ title: '最多选3个标签', icon: 'none' });
    } else {
      tags.splice(idx, 1);
    }
    this.setData({ 'form.tags': tags });
  },
  onChooseImg() {
    const that = this;
    wx.chooseImage({
      count: 6 - that.data.form.images.length,
      sizeType: ['original','compressed'],
      sourceType: ['album','camera'],
      success(res) {
        let imgs = that.data.form.images.concat(res.tempFilePaths);
        if (imgs.length > 6) imgs = imgs.slice(0, 6);
        that.setData({ 'form.images': imgs });
      }
    });
  },
  onRemoveImg(e) {
    const idx = e.currentTarget.dataset.idx;
    let imgs = this.data.form.images.slice();
    imgs.splice(idx, 1);
    this.setData({ 'form.images': imgs });
  },
  submit() {
    const { title, desc, price, contact, category, tags, images } = this.data.form;
    if (!title.trim() || !price || !contact || !category || images.length === 0) {
      wx.showToast({ title: '请填写全部必填项', icon: 'none' }); return;
    }
    const user = wx.getStorageSync('userInfo') || {};
    if (!user.school_id) {
      wx.showToast({ title: '请先选择学校', icon: 'none' });
      setTimeout(()=>{ wx.redirectTo({ url: '/pages/select-school/select-school' }); }, 600); return;
    }
    let idleList = wx.getStorageSync('idleList') || [];
    idleList.unshift({
      id: Date.now(),
      school_id: user.school_id,
      title: title.trim(),
      desc, price, contact, category, tags, images,
      status: 'onsale',
      createTime: Date.now(),
      displayTime: this.formatTime(Date.now())
    });
    wx.setStorageSync('idleList', idleList);
    wx.showToast({ title: '发布成功', icon: 'success' });
    // 通知上级页面刷新
    const pages = getCurrentPages();
    if (pages.length > 1 && pages[pages.length-2].route.indexOf('idle/idle') !== -1) {
      pages[pages.length-2].onShow && pages[pages.length-2].onShow();
    }
    setTimeout(()=>{ wx.navigateBack(); }, 900);
  },
  formatTime(ts) {
    const d = new Date(ts);
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
  }
});