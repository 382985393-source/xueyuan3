Page({
  data: {
    categoryList: ['全部','数码','图书','美妆','家具','运动','其它'],
    selectedCategory: '全部',
    idleList: []
  },
  onShow() {
    this.filterList();
  },
  onCategoryTap(e) {
    const cat = e.currentTarget.dataset.category;
    this.setData({ selectedCategory: cat }, this.filterList);
  },
  onSearchInput(e) {
    this.searchText = e.detail.value.trim();
    this.filterList();
  },
  filterList() {
    const user = wx.getStorageSync('userInfo') || {};
    let idleList = wx.getStorageSync('idleList') || [];
    // 只筛选本校
    idleList = idleList.filter(item => item.school_id === user.school_id);
    // 分类筛选
    if (this.data.selectedCategory && this.data.selectedCategory !== '全部') {
      idleList = idleList.filter(item => item.category === this.data.selectedCategory);
    }
    // 搜索筛选
    if (this.searchText) {
      idleList = idleList.filter(item =>
        item.title.includes(this.searchText) ||
        item.desc.includes(this.searchText) ||
        item.tags.join(',').includes(this.searchText)
      );
    }
    idleList.forEach(item => {
      item.displayTime = this.formatTime(item.createTime);
    });
    this.setData({ idleList });
  },
  goPublish() {
    wx.navigateTo({ url: '/pages/idle/publish' });
  },
  goDetail(e) {
    wx.navigateTo({ url: `/pages/idle/detail?id=${e.currentTarget.dataset.id}` });
  },
  formatTime(ts) {
    const d = new Date(ts);
    return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()} ${d.getHours()}:${String(d.getMinutes()).padStart(2,'0')}`;
  }
});