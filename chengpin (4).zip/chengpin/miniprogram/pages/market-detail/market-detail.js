Page({
  data: {
    item: null,
    userPoints: 0
  },
  onLoad(options) {
    // 假设商品信息通过页面参数或全局数据传递
    const { id } = options;
    // 用本地静态数据演示
    const items = [
      { id: 1, title: "无线蓝牙耳机", img: "/assets/market/earphone.png", points: 500, desc: "高保真音质，长续航" },
      { id: 2, title: "定制帆布袋", img: "/assets/market/bag.png", points: 200, desc: "环保耐用，校园专属" }
    ];
    const item = items.find(i => i.id == id);
    const userInfo = wx.getStorageSync('userInfo') || {};
    this.setData({
      item,
      userPoints: userInfo.points || 0
    });
  },
  exchange() {
    const { item, userPoints } = this.data;
    if (userPoints < item.points) {
      wx.showToast({ title: '积分不足', icon: 'none' });
      return;
    }
    wx.showModal({
      title: '兑换确认',
      content: `确定要用${item.points}积分兑换「${item.title}」吗？`,
      success: (res) => {
        if (res.confirm) {
          // 扣除积分并保存
          let userInfo = wx.getStorageSync('userInfo') || {};
          userInfo.points = (userInfo.points || 0) - item.points;
          wx.setStorageSync('userInfo', userInfo);

          // 生成订单（本地模拟，可扩展到云端）
          let orders = wx.getStorageSync('orders') || [];
          orders.push({ ...item, time: Date.now(), status: "待发货" });
          wx.setStorageSync('orders', orders);

          wx.showToast({ title: '兑换成功', icon: 'success' });
          // 返回并刷新个人中心、钱包等页面
          setTimeout(() => { wx.navigateBack(); }, 1200);
        }
      }
    });
  }
});