Page({
  data: {
    items: [
      { _id: '1', title: '二手自行车', price: 120, cover: '/assets/boards/market.svg' },
      { _id: '2', title: '二手台灯', price: 20, cover: '/assets/boards/market.svg' }
    ]
  }
});