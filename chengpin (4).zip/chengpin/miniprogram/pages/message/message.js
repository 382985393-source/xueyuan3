Page({
  data: {
    msgGroups: [
      {
        name: "系统通知",
        emoji: "📢",
        list: [
          { id: 1, text: "积分到账20分", date: "10-15 12:00", unread: true },
          { id: 2, text: "活动上线啦", date: "10-14 15:00", unread: false }
        ]
      },
      {
        name: "互动消息",
        emoji: "💡",
        list: [
          { id: 11, text: "有人评论了你的帖子", date: "10-15 13:12", unread: true },
          { id: 12, text: "你的帖子被点赞", date: "10-14 14:22", unread: false }
        ]
      },
      {
        name: "任务通知",
        emoji: "📝",
        list: [
          { id: 21, text: "任务已完成，积分+30", date: "10-13 09:00", unread: false }
        ]
      }
    ]
  },
  goDetail(e) {
    wx.showToast({title:'进入消息详情（待开发）',icon:'none'});
  }
});