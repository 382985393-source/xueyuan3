Component({
  data: {
    tabList: [
      {
        pagePath: "/pages/home/home",
        text: "首页",
        emoji: "🏠",
        bg: "linear-gradient(120deg,#aee1ff,#ffe7c5)",
        color: "#888",
        selectedColor: "#2d8cf0",
        selected: false
      },
      {
        pagePath: "/pages/tasks/tasks",
        text: "任务大厅",
        emoji: "📝",
        bg: "linear-gradient(120deg,#ffe7c5,#aee1ff)",
        color: "#888",
        selectedColor: "#2d8cf0",
        selected: false
      },
      {
        pagePath: "/pages/market/market",
        text: "商城",
        emoji: "🛒",
        bg: "linear-gradient(120deg,#ffc1e3,#a1f7d7)",
        color: "#888",
        selectedColor: "#2d8cf0",
        selected: false
      },
      {
        pagePath: "/pages/personal/personal",
        text: "我的",
        emoji: "👤",
        bg: "linear-gradient(120deg,#d1e7ff,#fdf6b7)",
        color: "#888",
        selectedColor: "#2d8cf0",
        selected: false
      }
    ]
  },
  attached() {
    this.updateSelected();
  },
  pageLifetimes: {
    show() {
      this.updateSelected();
    }
  },
  methods: {
    switchTab(e) {
      const path = e.currentTarget.dataset.path;
      wx.switchTab({ url: path });
    },
    updateSelected() {
      const pages = getCurrentPages();
      if (!pages.length) return; // 防止报错
      const currentPath = "/" + pages[pages.length - 1].route;
      this.setData({
        tabList: this.data.tabList.map(item => ({
          ...item,
          selected: item.pagePath === currentPath
        }))
      });
    }
  }
});