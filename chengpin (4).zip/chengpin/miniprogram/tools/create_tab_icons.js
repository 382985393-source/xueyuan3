// Node 脚本：在 miniprogram/assets/tab/ 下生成占位 png 文件（6 个）
const fs = require('fs');
const path = require('path');

const outDir = path.join(__dirname, '..', 'assets', 'tab');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

// 1x1 transparent PNG (small placeholder). 如果你有真实 icon，请替换这些文件。
const placeholderBase64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAsMB9U3M5aMAAAAASUVORK5CYII=';

const files = [
  'home.png',
  'home_active.png',
  'points.png',
  'points_active.png',
  'personal.png',
  'personal_active.png'
];

files.forEach(name => {
  const filePath = path.join(outDir, name);
  fs.writeFileSync(filePath, Buffer.from(placeholderBase64, 'base64'));
  console.log('written', filePath);
});

console.log('Done. Created placeholder icons in', outDir);