function waitForCloudInit(timeout = 3000) {
  return new Promise((resolve) => {
    const start = Date.now();
    const check = () => {
      const app = (typeof getApp === 'function') ? getApp() : null;
      if (app && app.globalData && app.globalData.cloudInited) return resolve(true);
      if (Date.now() - start >= timeout) return resolve(false);
      setTimeout(check, 100);
    };
    check();
  });
}

module.exports = {
  async call(funcName, data = {}) {
    try {
      console.log('[api.call] func:', funcName, 'payload:', data);
      if (!wx || !wx.cloud) {
        const msg = '当前环境不支持 wx.cloud';
        console.error(msg);
        return { ok: false, msg };
      }
      const inited = await waitForCloudInit(3000);
      if (!inited) {
        const msg = 'Cloud API 未就绪，请确保 app.js 已调用 wx.cloud.init()';
        console.error(msg);
        return { ok: false, msg };
      }
      const res = await wx.cloud.callFunction({ name: funcName, data });
      console.log('[api.call] raw response:', res);
      if (!res || !res.result) return { ok: false, msg: '云函数无返回' };
      return res.result;
    } catch (e) {
      console.error('api.call error', funcName, e);
      return { ok: false, msg: e && e.message ? e.message : '云函数调用失败' };
    }
  },

  // 小纸条时间格式化
  formatTime(timestamp) {
    if (!timestamp) return '';
    const d = new Date(timestamp);
    const pad = n => (n < 10 ? '0' + n : n);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
};