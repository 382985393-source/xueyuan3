// 统一管理分类（boards）配置：使用小图标占位（emoji）+ 渐变背景
// 修改此文件即可在首页/分类页同步生效

const BOARDS = [
  { id: 'reward', name: '悬赏榜', url: '/pages/reward/reward', emoji: '🎯', gradient: 'background: linear-gradient(135deg,#ff9a9e,#fad0c4);', showOnHome: true },
  { id: 'errands', name: '跑腿代购', url: '/pages/errands/errands', emoji: '🚴', gradient: 'background: linear-gradient(135deg,#a18cd1,#fbc2eb);', showOnHome: true },
  { id: 'bottle', name: '漂流瓶', url: '/pages/bottle/bottle', emoji: '🍾', gradient: 'background: linear-gradient(135deg,#84fab0,#8fd3f4);', showOnHome: true },
  { id: 'points', name: '积分中心', url: '/pages/points/points', emoji: '🏆', gradient: 'background: linear-gradient(135deg,#fddb92,#d1fdff);', showOnHome: true },
  { id: 'market', name: '商城', url: '/pages/market/market', emoji: '🛍️', gradient: 'background: linear-gradient(135deg,#ffd89b,#19547b);', showOnHome: true },
  { id: 'lostfound', name: '失物招领', url: '/pages/lostfound/lostfound', emoji: '🔎', gradient: 'background: linear-gradient(135deg,#cfd9df,#e2ebf0);', showOnHome: true },
  { id: 'game', name: '游戏交友', url: '/pages/game-social/game-social', emoji: '🎮', gradient: 'background: linear-gradient(135deg,#89f7fe,#66a6ff);', showOnHome: true },
  { id: 'jobs', name: '兼职招聘', url: '/pages/jobs/jobs', emoji: '💼', gradient: 'background: linear-gradient(135deg,#f6d365,#fda085);', showOnHome: true },
  { id: 'help', name: '打听求助', url: '/pages/help/help', emoji: '❓', gradient: 'background: linear-gradient(135deg,#e0c3fc,#8ec5fc);', showOnHome: true },
  { id: 'gossip', name: '吃瓜吐槽', url: '/pages/gossip/gossip', emoji: '🍉', gradient: 'background: linear-gradient(135deg,#fbc2eb,#a6c1ee);', showOnHome: true },
  { id: 'promo', name: '推广赚钱', url: '/pages/promo/promo', emoji: '📣', gradient: 'background: linear-gradient(135deg,#ffd89b,#ff6a88);', showOnHome: true },
  { id: 'confess', name: '告白', url: '/pages/confess/confess', emoji: '💌', gradient: 'background: linear-gradient(135deg,#ff9a9e,#fad0c4);', showOnHome: true }
];

module.exports = {
  getBoards({ showOnHome = true, limit = 12 } = {}) {
    const list = BOARDS.filter(b => (showOnHome ? b.showOnHome : true));
    if (showOnHome) return list.slice(0, limit);
    return list.slice();
  },
  getAllBoards() { return BOARDS.slice(); },
  findById(id) { return BOARDS.find(b => b.id === id); }
};