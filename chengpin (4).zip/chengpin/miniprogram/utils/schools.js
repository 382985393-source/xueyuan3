module.exports = [
  { id: 1, name: "清华大学", pinyin: "qinghuadaxue" },
  { id: 2, name: "北京大学", pinyin: "beijingdaxue" },
  { id: 3, name: "复旦大学", pinyin: "fudandaxue" },
  { id: 4, name: "上海中学", pinyin: "shanghaizhongxue" },
  { id: 5, name: "深圳中学", pinyin: "shenzhenzhongxue" },
  // ...全国大学、高中持续补全...
]