function formatTime(timestamp) {
  if (!timestamp) return '';
  let ts = Number(timestamp);
  if (isNaN(ts) || ts < 1e11) ts = Date.now();
  const d = new Date(ts);
  if (isNaN(d.getTime())) return '';
  const pad = n => (n < 10 ? '0' + n : n);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

module.exports = {
  formatTime
};