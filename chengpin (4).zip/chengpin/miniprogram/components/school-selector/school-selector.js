Component({
  properties: {
    school: Object,
    schools: Array
  },
  data: {
    showList: false
  },
  methods: {
    openList() { this.setData({ showList: true }); },
    closeList() { this.setData({ showList: false }); },
    chooseSchool(e) {
      const id = e.currentTarget.dataset.id;
      this.triggerEvent('schoolchange', { school_id: id });
      this.setData({ showList: false });
    }
  }
});