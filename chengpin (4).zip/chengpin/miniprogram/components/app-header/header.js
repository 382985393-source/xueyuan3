Component({
  properties: {
    title: { type: String, value: '' },
    // fallback 路径，默认为首页；当没有历史栈时会跳转到该路径
    fallback: { type: String, value: '/pages/home/home' },
    // 如果 fallback 指向 tab 页面，设置为 true（会调用 switchTab）
    fallbackIsTab: { type: Boolean, value: true },
    // 是否显示返回按钮（允许某些页面隐藏）
    showBack: { type: Boolean, value: true }
  },
  methods: {
    onBack() {
      try {
        if (!this.data.showBack) return;
        const pages = getCurrentPages();
        if (pages && pages.length > 1) {
          wx.navigateBack();
          return;
        }
        // 没有历史栈，按配置决定使用 switchTab 或 navigateTo
        if (this.data.fallbackIsTab) {
          wx.switchTab({ url: this.data.fallback });
        } else {
          wx.navigateTo({ url: this.data.fallback });
        }
      } catch (e) {
        // 兜底切回首页
        try { wx.switchTab({ url: '/pages/home/home' }); } catch (err) {}
      }
    }
  }
});