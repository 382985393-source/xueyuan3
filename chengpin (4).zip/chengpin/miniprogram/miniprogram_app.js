App({
  onLaunch() {
    wx.cloud.init({
      env: 'cloud1-7g8iq6uq038e8d59', // ← 请填写你的环境ID
      traceUser: true
    });
  }
});