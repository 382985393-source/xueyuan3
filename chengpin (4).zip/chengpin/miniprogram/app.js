App({
    onLaunch() {
      // 请把下面 env 改成你的环境ID（可选但推荐）
      try {
        wx.cloud.init({
          env: 'cloud1-7g8iq6uq038e8d59', // 例如 'prod-abc123'，或留空使用当前 DevTools 选择的环境
          traceUser: true
        });
        console.log('wx.cloud initialized in app.js');
        // 标记已初始化，供其它模块轮询检查
        this.globalData = this.globalData || {};
        this.globalData.cloudInited = true;
      } catch (e) {
        console.error('wx.cloud.init failed in app.js', e);
        // 仍要设置标记为 false，方便检查
        this.globalData = this.globalData || {};
        this.globalData.cloudInited = false;
      }
    },
    globalData: {
      cloudInited: false
    }
  });